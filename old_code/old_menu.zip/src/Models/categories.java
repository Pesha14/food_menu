/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;

/**
 *
 * @author USER
 */
public class categories {
 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author KongMagneto
 */

    
    private int category_id;
    private String category_name;
    

    /**
     * @return the cat_id
     */
    public int getCategory_id() {
        return category_id;
    }

    
    public void setCategory_id(int cat_id) {
        this.category_id = cat_id;
    }

    /**
     * @return the cat_name
     */
    public String getCategory_name() {
        return category_name;
    }

    
    public void setCategory_name(String category_name) {
        this.category_name = category_name;
    }

    
   
}
