/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;

/**
 *
 * @author USER
 */
public class staffDetails {
    
    
    private String StaffName;
    private String StaffID;
     private String StaffDepartment;

    public String getStaffName() {
        return StaffName;
    }

    public void setStaffName(String StaffName) {
        this.StaffName = StaffName;
    }

    public String getStaffID() {
        return StaffID;
    }

    public void setStaffID(String StaffID) {
        this.StaffID = StaffID;
    }

    public String getStaffDepartment() {
        return StaffDepartment;
    }

    public void setStaffDepartment(String StaffDepartment) {
        this.StaffDepartment = StaffDepartment;
    }
    
}
