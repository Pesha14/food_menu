/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import javax.print.PrintService;
import javax.swing.ImageIcon;

/**
 *
 * @author USER
 */
public class BillPrintable implements Printable {

    private final PrintService[] printService;

    String company_name;
    String Address;
    String Telephone;
    String Receipt_no;
    String Staff_name;
    String Staff_id;
    String department;
    // String menu;
    ArrayList<String> menu;
    ArrayList<Double> item_cost;
    double total_cost;
    double boa_discount;
    double cash_payment;
    double boa_discount_balance;
 

    public BillPrintable(String company_name, String Address, String Telephone, String Receipt_no, String Staff_name, 
            String Staff_id, String department, ArrayList menu, ArrayList item_cost, double total_cost,double boa_discount,double cash_payment) {
        this.company_name = company_name;
        this.Address = Address;
        this.Telephone = Telephone;
        this.Receipt_no = Receipt_no;
        this.Staff_name = Staff_name;
        this.Staff_id = Staff_id;
        this.department = department;
        this.menu = menu;
        this.item_cost = item_cost;
        this.total_cost = total_cost;
        this.boa_discount=boa_discount;
        this.cash_payment= cash_payment;
        this.printService = PrinterJob.lookupPrintServices();

    }

    
    public BillPrintable(String company_name, String Address, String Telephone, String Receipt_no, String Staff_name, 
            String Staff_id, String department, ArrayList menu, ArrayList item_cost, double total_cost,double boa_discount,double boa_discount_balance,double cash_payment) {
        this.company_name = company_name;
        this.Address = Address;
        this.Telephone = Telephone;
        this.Receipt_no = Receipt_no;
        this.Staff_name = Staff_name;
        this.Staff_id = Staff_id;
        this.department = department;
        this.menu = menu;
        this.item_cost = item_cost;
        this.total_cost = total_cost;
        this.boa_discount=boa_discount;
        this.cash_payment= cash_payment;
        this.printService = PrinterJob.lookupPrintServices();
        this.boa_discount_balance=boa_discount_balance;

    }
    
    
    public void drawCenteredString(String s, int w, int h, Graphics g) {
        FontMetrics fm = g.getFontMetrics();
        int x = (w - fm.stringWidth(s)) / 2;
        int y = (fm.getAscent() + (h - (fm.getAscent() + fm.getDescent())) / 2);
        g.drawString(s, x, y);
    }

    @Override
    public int print(Graphics graphics, PageFormat pageFormat, int pageIndex)
            throws PrinterException {

        SimpleDateFormat dateFormat
                = new SimpleDateFormat("d MMM yyyy H:mm:ss ");

        Calendar currentCalendar = Calendar.getInstance();
        Date currentTime = currentCalendar.getTime();
        String print_date = dateFormat.format(currentTime);

        int r = menu.size();
        //  ImageIcon icon=new ImageIcon("C:UsersccsDocumentsNetBeansProjectsvideo TestPOSInvoicesrcposinvoicemylogo.jpg"); 
        int result = NO_SUCH_PAGE;
        if (pageIndex == 0) {

            Graphics2D g2d = (Graphics2D) graphics;
            double width = pageFormat.getImageableWidth();
            g2d.translate((int) pageFormat.getImageableX(), (int) pageFormat.getImageableY());

            //  FontMetrics metrics=g2d.getFontMetrics(new Font("Arial",Font.BOLD,7));
            try {
                int y = 20;
                int yShift = 10;
                int headerRectHeight = 15;
                // int headerRectHeighta=40;

                g2d.setFont(new Font("Monospaced", Font.BOLD, 10));

                // g2d.drawImage(icon.getImage(), 50, 20, 90, 30, rootPane);y+=yShift+30;
                g2d.drawString("-------------------------------------", 12, y);
                y += yShift;
                g2d.drawString("         " + company_name + "        ", 12, y);
                y += yShift;
                g2d.drawString("         \n\n        ", 12, y);
                y += yShift;

//            g2d.drawString("   "+Address+" ",12,y);y+=yShift;
//            g2d.drawString("   Tel: "+Telephone+" ",12,y);y+=yShift;
                g2d.drawString("   Receipt No : " + Receipt_no, 12, y);
                y += yShift;

                g2d.drawString("-------------------------------------", 12, y);
                y += headerRectHeight;
                g2d.setFont(new Font("Monospaced", Font.PLAIN, 9));
                g2d.drawString("   Staff Name : " + Staff_name, 12, y);
                y += yShift;
                // g2d.drawString("   Staff ID No : "+Staff_id,12,y);y+=yShift;
                g2d.drawString("   Department : " + department, 12, y);
                y += yShift;
                //  g2d.drawString("   Menu : "+menu,12,y);y+=yShift;
                g2d.drawString("   Menu : ", 12, y);
                y += yShift;
//            g2d.drawString("-------------------------------------",10,y);y+=headerRectHeight;
//     
//  

                for (int s = 0; s < r; s++) {
                    g2d.drawString("   " + menu.get(s) + "   " + item_cost.get(s), 10, y);
                    y += yShift;

                }

//          
            g2d.drawString("-------------------------------------",10,y);y+=yShift;
            g2d.drawString(" Total amount:               "+total_cost+"   ",10,y);
            y+=yShift;
            y+=yShift;
//            g2d.drawString("-------------------------------------",10,y);y+=yShift;
//            g2d.drawString(" Cash      :                 "+txtcash.getText()+"   ",10,y);y+=yShift;
//            g2d.drawString("-------------------------------------",10,y);y+=yShift;
//            g2d.drawString(" Served By   :                   ",10,y);y+=yShift;

                g2d.drawString(" BOA Disc :              " + boa_discount, 12, y);
                y += yShift;
                 g2d.drawString(" BOA Disc Balance :       " + boa_discount_balance, 12, y);
                y += yShift;
                // g2d.drawString("   Staff ID No : "+Staff_id,12,y);y+=yShift;
                g2d.drawString(" Cash Payment  :           " + cash_payment, 12, y);
                y += yShift;

                g2d.drawString("*************************************", 10, y);
                y += yShift;
                g2d.drawString("       Served By :            ", 10, y);
                y += yShift;
                g2d.drawString("*************************************", 10, y);
                y += yShift;
                g2d.drawString(print_date, 10, y);
                y += yShift;

            } catch (Exception e) {
                e.printStackTrace();
            }

            result = PAGE_EXISTS;
        }
        return result;
    }
}
