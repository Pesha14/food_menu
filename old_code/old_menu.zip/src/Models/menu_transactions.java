/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;

/**
 *
 * @author USER
 */
public class menu_transactions {
    
    private int t_id;
    private String staff_id;
    private int menu_id;
    private double meal_cost;
    private double discount_amt;
    private double paid_amt;
    private int payment_method;
    private String receipt_no;
    private String trans_time;
    private int booking_id;

    /**
     * @return the t_id
     */
    public int getT_id() {
        return t_id;
    }

    /**
     * @param t_id the t_id to set
     */
    public void setT_id(int t_id) {
        this.t_id = t_id;
    }

    /**
     * @return the staff_id
     */
    public String getStaff_id() {
        return staff_id;
    }

    /**
     * @param staff_id the staff_id to set
     */
    public void setStaff_id(String staff_id) {
        this.staff_id = staff_id;
    }

    /**
     * @return the menu_id
     */
    public int getMenu_id() {
        return menu_id;
    }

    /**
     * @param menu_id the menu_id to set
     */
    public void setMenu_id(int menu_id) {
        this.menu_id = menu_id;
    }

    /**
     * @return the meal_cost
     */
    public double getMeal_cost() {
        return meal_cost;
    }

    /**
     * @param meal_cost the meal_cost to set
     */
    public void setMeal_cost(double meal_cost) {
        this.meal_cost = meal_cost;
    }

    /**
     * @return the discount_amt
     */
    public double getDiscount_amt() {
        return discount_amt;
    }

    /**
     * @param discount_amt the discount_amt to set
     */
    public void setDiscount_amt(double discount_amt) {
        this.discount_amt = discount_amt;
    }

    /**
     * @return the paid_amt
     */
    public double getPaid_amt() {
        return paid_amt;
    }

    /**
     * @param paid_amt the paid_amt to set
     */
    public void setPaid_amt(double paid_amt) {
        this.paid_amt = paid_amt;
    }

    /**
     * @return the payment_method
     */
    public int getPayment_method() {
        return payment_method;
    }

    /**
     * @param payment_method the payment_method to set
     */
    public void setPayment_method(int payment_method) {
        this.payment_method = payment_method;
    }

    /**
     * @return the receipt_no
     */
    public String getReceipt_no() {
        return receipt_no;
    }

    /**
     * @param receipt_no the receipt_no to set
     */
    public void setReceipt_no(String receipt_no) {
        this.receipt_no = receipt_no;
    }

    /**
     * @return the trans_time
     */
    public String getTrans_time() {
        return trans_time;
    }

    /**
     * @param trans_time the trans_time to set
     */
    public void setTrans_time(String trans_time) {
        this.trans_time = trans_time;
    }

    /**
     * @return the booking_id
     */
    public int getBooking_id() {
        return booking_id;
    }

    /**
     * @param booking_id the booking_id to set
     */
    public void setBooking_id(int booking_id) {
        this.booking_id = booking_id;
    }
    
    
}