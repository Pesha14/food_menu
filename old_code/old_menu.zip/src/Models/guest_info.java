/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;

/**
 *
 * @author USER
 */
public class guest_info {
    private int booking_id;
    private String guest_name;
    private String guest_pin;
    private int menu_id;
    private String menu_name;
    private double menu_price;
    private double discount_amt;
    private String staff_id;
    private String staff_name;
    private String d_name;

    /**
     * @return the booking_id
     */
    public int getBooking_id() {
        return booking_id;
    }

    /**
     * @param booking_id the booking_id to set
     */
    public void setBooking_id(int booking_id) {
        this.booking_id = booking_id;
    }

    /**
     * @return the guest_name
     */
    public String getGuest_name() {
        return guest_name;
    }

    /**
     * @param guest_name the guest_name to set
     */
    public void setGuest_name(String guest_name) {
        this.guest_name = guest_name;
    }

    /**
     * @return the guest_pin
     */
    public String getGuest_pin() {
        return guest_pin;
    }

    /**
     * @param guest_pin the guest_pin to set
     */
    public void setGuest_pin(String guest_pin) {
        this.guest_pin = guest_pin;
    }

    /**
     * @return the menu_id
     */
    public int getMenu_id() {
        return menu_id;
    }

    /**
     * @param menu_id the menu_id to set
     */
    public void setMenu_id(int menu_id) {
        this.menu_id = menu_id;
    }

    /**
     * @return the menu_name
     */
    public String getMenu_name() {
        return menu_name;
    }

    /**
     * @param menu_name the menu_name to set
     */
    public void setMenu_name(String menu_name) {
        this.menu_name = menu_name;
    }

    /**
     * @return the menu_price
     */
    public double getMenu_price() {
        return menu_price;
    }

    /**
     * @param menu_price the menu_price to set
     */
    public void setMenu_price(double menu_price) {
        this.menu_price = menu_price;
    }

    /**
     * @return the discount_amt
     */
    public double getDiscount_amt() {
        return discount_amt;
    }

    /**
     * @param discount_amt the discount_amt to set
     */
    public void setDiscount_amt(double discount_amt) {
        this.discount_amt = discount_amt;
    }

    /**
     * @return the staff_id
     */
    public String getStaff_id() {
        return staff_id;
    }

    /**
     * @param staff_id the staff_id to set
     */
    public void setStaff_id(String staff_id) {
        this.staff_id = staff_id;
    }

    /**
     * @return the staff_name
     */
    public String getStaff_name() {
        return staff_name;
    }

    /**
     * @param staff_name the staff_name to set
     */
    public void setStaff_name(String staff_name) {
        this.staff_name = staff_name;
    }

    /**
     * @return the d_name
     */
    public String getD_name() {
        return d_name;
    }

    /**
     * @param d_name the d_name to set
     */
    public void setD_name(String d_name) {
        this.d_name = d_name;
    }
    
     
}
