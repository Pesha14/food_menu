/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;

/**
 *
 * @author USER
 */



import java.awt.*;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;

public class ReceiptFormats {

    public static Printable patientReceipt(String receiptCode){
        return new Printable() {
            @Override
            public int print(Graphics g, PageFormat pf, int page) throws PrinterException {
                if (page > 0) {
                    return NO_SUCH_PAGE;
                }

                //starting positions
                int x = 5;
                int y = 5;

                int xLarger = 60;
                int xLarger2 = 100;
                int yNextAfterLogo = 30;
                int yNextLarger = 20;

                int footerImgSize = 40;

                int startRectX = 0;
                int startRectY = 0;
                int rectWidth = 95;

                Graphics2D g2d = (Graphics2D) g;
                g2d.translate(pf.getImageableX(), pf.getImageableY());

                //first logo
//                g.drawImage(UtJobs.getBufImg(UtData.hospitalIcon),xLarger,0,120,
//                        60, null);
                y += 60 + yNextAfterLogo;

                //Message
                g.setFont(new Font("Roman", Font.BOLD, 12));

                g.drawString("TOKEN NO: ", x, y);
                y += yNextAfterLogo;

                //Unique Identifier
                g.setFont(new Font("Roman", Font.PLAIN, 14));
                g.drawString(receiptCode,xLarger,y);
                y += yNextLarger;

                y += yNextAfterLogo;

                return PAGE_EXISTS;

            }
        };
    }

}
