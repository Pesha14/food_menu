/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;

/**
 *
 * @author USER
 */
public class menus {
 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author KongMagneto
 */

    
    private int menu_id;
    private String menu_name;
    private int start_hour;
    private int end_hour;
    private double menu_price;
    private int discountable;
    private double discount_amt;

    /**
     * @return the menu_id
     */
    public int getMenu_id() {
        return menu_id;
    }

    /**
     * @param menu_id the menu_id to set
     */
    public void setMenu_id(int menu_id) {
        this.menu_id = menu_id;
    }

    /**
     * @return the menu_name
     */
    public String getMenu_name() {
        return menu_name;
    }

    /**
     * @param menu_name the menu_name to set
     */
    public void setMenu_name(String menu_name) {
        this.menu_name = menu_name;
    }

    /**
     * @return the start_hour
     */
    public int getStart_hour() {
        return start_hour;
    }

    /**
     * @param start_hour the start_hour to set
     */
    public void setStart_hour(int start_hour) {
        this.start_hour = start_hour;
    }

    /**
     * @return the end_hour
     */
    public int getEnd_hour() {
        return end_hour;
    }

    /**
     * @param end_hour the end_hour to set
     */
    public void setEnd_hour(int end_hour) {
        this.end_hour = end_hour;
    }

    /**
     * @return the menu_price
     */
    public double getMenu_price() {
        return menu_price;
    }

    /**
     * @param menu_price the menu_price to set
     */
    public void setMenu_price(double menu_price) {
        this.menu_price = menu_price;
    }

    /**
     * @return the discountable
     */
    public int getDiscountable() {
        return discountable;
    }

    /**
     * @param discountable the discountable to set
     */
    public void setDiscountable(int discountable) {
        this.discountable = discountable;
    }

    /**
     * @return the discount_amt
     */
    public double getDiscount_amt() {
        return discount_amt;
    }

    /**
     * @param discount_amt the discount_amt to set
     */
    public void setDiscount_amt(double discount_amt) {
        this.discount_amt = discount_amt;
    }
    
    

   
}
