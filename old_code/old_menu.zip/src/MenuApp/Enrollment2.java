package MenuApp;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.InvocationTargetException;
import java.sql.SQLException;

import javax.swing.JOptionPane;

import com.digitalpersona.uareu.Engine;
import com.digitalpersona.uareu.Fid;
import com.digitalpersona.uareu.Fmd;
import com.digitalpersona.uareu.Reader;
import com.digitalpersona.uareu.UareUException;
import com.digitalpersona.uareu.UareUGlobal;
import java.awt.Color;
import java.util.logging.Level;

public class Enrollment2 implements ActionListener {

    public class EnrollmentThread extends Thread implements
            Engine.EnrollmentCallback {

        public static final String ACT_PROMPT = "enrollment_prompt";
        public static final String ACT_CAPTURE = "enrollment_capture";
        public static final String ACT_FEATURES = "enrollment_features";
        public static final String ACT_DONE = "enrollment_done";
        public static final String ACT_CANCELED = "enrollment_canceled";
        public static final String ACT_SAVE = "save";

        public class EnrollmentEvent extends ActionEvent {

            private static final long serialVersionUID = 102;

            public Reader.CaptureResult capture_result;
            public Reader.Status reader_status;
            public UareUException exception;
            public Fmd enrollment_fmd;

            public EnrollmentEvent(Object source, String action, Fmd fmd,
                    Reader.CaptureResult cr, Reader.Status st, UareUException ex) {
                super(source, ActionEvent.ACTION_PERFORMED, action);
                capture_result = cr;
                reader_status = st;
                exception = ex;
                enrollment_fmd = fmd;
            }
        }

        private final Reader m_reader;
        private CaptureThread m_capture;
        private final ActionListener m_listener;
        private boolean m_bCancel;

        protected EnrollmentThread(Reader reader, ActionListener listener) {
            m_reader = reader;
            m_listener = listener;
        }

        @Override
        public Engine.PreEnrollmentFmd GetFmd(Fmd.Format format) {
           
            Engine.PreEnrollmentFmd prefmd = null;

            while (null == prefmd && !m_bCancel) {
                // start capture thread
                m_capture = new CaptureThread(m_reader, false,
                        Fid.Format.ISO_19794_4_2005,
                        Reader.ImageProcessing.IMG_PROC_DEFAULT);
                m_capture.start(null);

                // prompt for finger
                SendToListener(ACT_PROMPT, null, null, null, null);

                // wait till done
                m_capture.join(0);

                // check result
                CaptureThread.CaptureEvent evt = m_capture
                       .getLastCaptureEvent();
                if (null != evt.capture_result) {
                    if (Reader.CaptureQuality.CANCELED == evt.capture_result.quality) {
                        // capture canceled, return null
                        
                        System.out.println("checking quality");
                        break;
                    } else if (null != evt.capture_result.image
                            && Reader.CaptureQuality.GOOD == evt.capture_result.quality) {
                        // Send image
                        System.out.println("checking first");
                        SendToListener(ACT_CAPTURE, null, evt.capture_result,
                                null, null);

                        // acquire engine
                        Engine engine = UareUGlobal.GetEngine();

                        try {
                            // extract features
                           
                            System.out.println("souting evt " + evt.capture_result.image);
                            Fmd fmdd =  engine.CreateFmd(evt.capture_result.image,Fmd.Format.DP_PRE_REG_FEATURES);
                           
                
                            //if(prefmd==null){
                            // return prefmd
                            prefmd = new Engine.PreEnrollmentFmd();
                            //}
                            prefmd.fmd = fmdd;
                            prefmd.view_index = 0;

                            // send success
                            SendToListener(ACT_FEATURES, null, null, null, null);
                        } catch (UareUException e) {
                            System.out.println(e.toString());
//                            System.out.println("error message " + e.getMessage().toString());
                            SendToListener(ACT_FEATURES, null, null, null, e);
                        }
                    } else {
                        // send quality result
                        SendToListener(ACT_CAPTURE, null, evt.capture_result,
                                evt.reader_status, evt.exception);
                    }
                } else {
                    // send capture error
                    SendToListener(ACT_CAPTURE, null, evt.capture_result,
                            evt.reader_status, evt.exception);
                }
            }

            return prefmd;
        }

        public void cancel() {
            m_bCancel = true;
            if (null != m_capture) {
                m_capture.cancel();
            }
        }

        private void SendToListener(String action, Fmd fmd,
                Reader.CaptureResult cr, Reader.Status st, UareUException ex) {
            if (null == m_listener || null == action || action.equals("")) {
                return;
            }

            final EnrollmentEvent evt = new EnrollmentEvent(this, action, fmd,
                    cr, st, ex);

            // invoke listener on EDT thread
            try {
                javax.swing.SwingUtilities.invokeAndWait(new Runnable() {
                    @Override
                    public void run() {
                        m_listener.actionPerformed(evt);
                    }
                });
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void run() {
            // acquire engine
            Engine engine = UareUGlobal.GetEngine();

            try {
                m_bCancel = false;
                while (!m_bCancel) {
                    // run enrollment
                    Fmd fmd = engine.CreateEnrollmentFmd(
                            Fmd.Format.DP_REG_FEATURES, this);

                    // send result
                    if (null != fmd) {

                        SendToListener(ACT_DONE, fmd, null, null, null);
                    } else {
                        SendToListener(ACT_CANCELED, null, null, null, null);
                        break;
                    }
                }
            } catch (UareUException e) {
                JOptionPane.showMessageDialog(null,
                        "Exception during creation of data and import");
                SendToListener(ACT_DONE, null, null, null, e);
            }
        }
    }

    private static final long serialVersionUID = 6;
    private static final String ACT_BACK = "back";
    private static final String ACT_SAVE = "save";
    private static final String ACT_SAVE_DB = "save2db";

    public com.digitalpersona.uareu.Fmd enrollmentFMD;
    private final EnrollmentThread m_enrollment;
    private final Reader m_reader;
    
    
    
    
    private boolean m_bJustStarted;
   
    static int count = 0;

    private Enrollment2(Reader reader) {
        m_reader = reader;
        m_bJustStarted = true;
        m_enrollment = new EnrollmentThread(m_reader, this);

             

       
    }

    private void saveToDB() {
        FingerDB db = new FingerDB("localhost", "zarida", "root", "root");

        try {
            db.Open();
            //if (this.username_text.getText().isEmpty() != true) {
            // Check if user already exists
            //if (db.UserExists(this.username_text.getText()) == false) {
            // Save user to database along with fingerprint minutiae
            db.Update(App.txtid.getText().trim(),
                    this.enrollmentFMD.getData());
           
//					} else {
//						JOptionPane.showMessageDialog(null,
//								"Username already taken.");
//						this.username_text.requestFocusInWindow();
//					}

//				} else {
//					JOptionPane.showMessageDialog(null,
//							"Please enter a unique username");
//					this.username_text.requestFocusInWindow();
//				}
//Kill the enrollment thread
            System.out.println("Data Saved");
            m_enrollment.cancel();

            // close reader
            try {
                m_reader.Close();
            } catch (UareUException e) {
                MessageBox.DpError("Reader.Close()", e);
            }

        } catch (SQLException e3) {
            JOptionPane.showMessageDialog(null, e3.getMessage());
            App.logger.log(Level.WARNING, "DB ERROR {0}", e3.getMessage());
        }
        try {
            db.Close();
        } catch (SQLException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        } //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void actionPerformed(ActionEvent e) {
//		if (e.getActionCommand().equals(ACT_BACK)) {
//			// destroy dialog to cancel enrollment
//			m_dlgParent.setVisible(false);
//
//			return;
//		} else if (e.getActionCommand().equals(ACT_SAVE_DB)) {
//			FingerDB db = new FingerDB("localhost", "zarida", "root", "root");
//			try {
//				db.Open();
//				if (this.username_text.getText().isEmpty() != true) {
//					// Check if user already exists
//					//if (db.UserExists(this.username_text.getText()) == false) {
//						// Save user to database along with fingerprint minutiae
//						db.Update(this.username_text.getText(),
//								this.enrollmentFMD.getData());
//						m_dlgParent.setVisible(false);
////					} else {
////						JOptionPane.showMessageDialog(null,
////								"Username already taken.");
////						this.username_text.requestFocusInWindow();
////					}
//
//				} else {
//					JOptionPane.showMessageDialog(null,
//							"Please enter a unique username");
//					this.username_text.requestFocusInWindow();
//				}
//
//			} catch (SQLException e3) {
//				JOptionPane.showMessageDialog(null, e3.getMessage());
//			}
//			try {
//				db.Close();
//			} catch (SQLException e1) {
//				// TODO Auto-generated catch block
//				e1.printStackTrace();
//			}
//		}

//		else if (e.getActionCommand().equals(ACT_SAVE)) {
//			saveDataToFile(username_text.getText(),enrollmentFMD.getData());
//			this.m_save.setEnabled(false);
//			return;
//		} 
        // } else {
        EnrollmentThread.EnrollmentEvent evt = (EnrollmentThread.EnrollmentEvent) e;
        System.err.println("Prompt " + e.getActionCommand());
        if (e.getActionCommand().equals(EnrollmentThread.ACT_PROMPT)) {
            if (m_bJustStarted) {
                count = count + 1;
                System.out.println("Enrollment started\n");
                System.out.println("Put your any finger on the reader\n");
               
                App.m_text.setText("put Any finger on the reader");

            } else {
                count = count + 1;
                System.out.println("put the same finger on the reader\n");
              //  m_text.append("    put the same finger on the reader\n");
                App.m_text.setText("put the Same finger on the reader");

                if (count == 3) {
                      System.out.println("put the Same finger on the reader Again\n");
                    App.m_text.setText("put the Same finger on the reader Again");
                }

                if (count == 4) {

                    System.out.println("Once more put the Same finger on the reader ");
                    App.m_text.setText("Once more put the Same finger on the reader ");
                }
                //m_text.append("    Put the same finger on the reader\n");
                System.out.println("Put the same finger on the reader\n");
            }
            m_bJustStarted = false;
        } else if (e.getActionCommand().equals(EnrollmentThread.ACT_CAPTURE)) {

            if (null != evt.capture_result) {
                if (evt.capture_result.image != null) //m_imagePanel.showImage(evt.capture_result.image);
                {
                    System.out.println("Score is " + evt.capture_result.score);
                }
            }
            System.out.println("Quality is " + evt.capture_result.quality);

            if (null != evt.capture_result) {
                // MessageBox.BadQuality(evt.capture_result.quality);
            } else if (null != evt.exception) {

                // MessageBox.DpError("Capture", evt.exception);
            } else if (null != evt.reader_status) {
                // MessageBox.BadStatus(evt.reader_status);
            }

            m_bJustStarted = false;
        } else if (e.getActionCommand().equals(
                EnrollmentThread.ACT_FEATURES)) {
            if (null == evt.exception) {
               // m_text.append("    fingerprint captured, features extracted\n\n");
                System.out.println("fingerprint captured, features extracted\n\n");
            } else {
                System.out.println("error getting fingure print");
                MessageBox.DpError("Feature extraction", evt.exception);
            }
            m_bJustStarted = false;
        } else if (e.getActionCommand().equals(EnrollmentThread.ACT_DONE)) {
            if (null == evt.exception) {
                String str = String
                        .format("    Enrollment template created, size: %d\n\n\nPlease save to file or verify.",
                                evt.enrollment_fmd.getData().length);

                enrollmentFMD = evt.enrollment_fmd;
                m_enrollment.cancel();
              
                saveToDB();
          
                System.out.println(str);
                App.m_text.setText("Registration Successful, Click Back To Start");
                App.cmdback.setVisible(true);
            } else {
                MessageBox.DpError("Enrollment template creation",
                        evt.exception);
                App.m_text.setForeground(Color.red);
                App.m_text.setText("Registration Error");
            }
            m_bJustStarted = true;
        } else if (e.getActionCommand().equals(
                EnrollmentThread.ACT_CANCELED)) {
            // canceled, destroy dialog
            //m_dlgParent.setVisible(false);
        }

        // cancel enrollment if any exception or bad reader status
        if (null != evt.exception) {
            System.out.println("No Exception Found");
        } else if (null != evt.reader_status
                && Reader.ReaderStatus.READY != evt.reader_status.status
                && Reader.ReaderStatus.NEED_CALIBRATION != evt.reader_status.status) {
          System.out.println("Error : Reader Status "+ evt.reader_status);
        }
        //}
    }

    

    private void doModal() {
        // open reader
		try {
			m_reader.Open(Reader.Priority.COOPERATIVE);
		} catch (UareUException e) {
			MessageBox.DpError("Reader.Open()", e);
		}

        // start enrollment thread
        m_enrollment.start();

        // bring up modal dialog
      
        // stop enrollment thread
        
//        if(!m_enrollment.isAlive()){
//        
//        m_enrollment.cancel();
//        
//         try {
//            m_reader.Close();
//        } catch (UareUException e) {
//            MessageBox.DpError("Reader.Close()", e);
//        }
//        
//        
//        }
        

        // close reader
       
    }

    public static Fmd Run(Reader reader) {
        //JDialog dlg = new JDialog((JDialog) null, "Enrollment", true);
        Enrollment2 enrollment = new Enrollment2(reader);

        enrollment.doModal();
        return enrollment.enrollmentFMD;
    }
}
