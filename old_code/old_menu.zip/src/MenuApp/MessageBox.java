package MenuApp;

import javax.swing.JOptionPane;

import com.digitalpersona.uareu.Reader;
import com.digitalpersona.uareu.UareUException;
import java.util.logging.Level;

public class MessageBox {
	public static void BadQuality(Reader.CaptureQuality q) {
            
            App.logger.log(Level.WARNING,"Bad Quality");
//		JOptionPane.showMessageDialog(null, q.toString(), "Bad quality",
//				JOptionPane.WARNING_MESSAGE);
	}

	public static void BadStatus(Reader.Status s) {
		String str = String.format("Reader status: %s", s.toString());
                
                 App.logger.log(Level.SEVERE,str);
//		JOptionPane.showMessageDialog(null, str, "Reader status",
//				JOptionPane.ERROR_MESSAGE);
	}

	public static void DpError(String strFunctionName, UareUException e) {
            e.printStackTrace();
		String str = String.format("%s returned DP error %d \n%s",
				strFunctionName, (e.getCode() & 0xffff), e.toString());
                 App.logger.log(Level.SEVERE,str);
//		JOptionPane.showMessageDialog(null, str, "Error",
//				JOptionPane.ERROR_MESSAGE);
	}

	public static void Warning(String strText) {
		JOptionPane.showMessageDialog(null, strText, "Warning",
				JOptionPane.WARNING_MESSAGE);
                 App.logger.log(Level.INFO,"Warning");
	}
}
