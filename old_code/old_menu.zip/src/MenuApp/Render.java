/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MenuApp;

import Utilities.UtData;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.UIManager;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

/**
 *
 * @author USER
 */
public class Render extends DefaultTableCellRenderer {

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, 
            boolean isSelected, boolean hasFocus, int row, int column) {
        
        if (table != null) {
      JTableHeader header = table.getTableHeader();
      if (header != null) {
          header.setSize(200, 150);
          header.setFont(new Font("Segoe UI",Font.BOLD,18));
          header.setForeground(Color.BLUE);
          header.setBorder(new LineBorder(Color.decode("#006699"),2));
//        setBackground(header.getBackground());
//        setFont(header.getFont());
      }
    }
      
        if(value instanceof JButton){
            JButton btn = (JButton)value;
            
//            
//            ((JButton) value).addActionListener(new ActionListener() {
//
//    @Override
//    public void actionPerformed(ActionEvent e) {
//        
//        System.out.println("Clicked");
//         
//        //your actions
//    }
//});
            
           if(isSelected){
                btn.setForeground(table.getSelectionForeground());
      btn.setBackground(table.getSelectionBackground());
                System.out.println("Selected Row "+row);
                removeSelectedRows(table);
                
            }else{
                btn.setForeground(table.getForeground());
      btn.setBackground(UIManager.getColor("Button.background"));
            }
           
            
//    setBorder(UIManager.getBorder("TableHeader.cellBorder"));
//    setHorizontalAlignment(JLabel.CENTER);
            
            
            return btn;
        }
        
        
//        if(value instanceof JCheckBox){
//            JCheckBox ch = (JCheckBox)value;
//            return ch;
//        }
        
        return super.getTableCellRendererComponent(table, value, isSelected, 
                hasFocus, row, column); //To change body of generated methods, choose Tools | Templates.
    }

  
    public void removeSelectedRows(JTable table){
   DefaultTableModel model = (DefaultTableModel) table.getModel();
   int[] rows = table.getSelectedRows();
   for(int i=0;i<rows.length;i++){
     model.removeRow(rows[i]-i);
       
   }
   
   
  
       App.elogger.debug("Table Size "+table.getRowCount());
        App.elogger.debug("List Size "+UtData.SELECTED_MENU_ITEMS.size());
   
}

    
     
   


    
    
  
}