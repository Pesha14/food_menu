package MenuApp;

import Models.Items;
import Models.categories;
import Models.guest_info;
import Models.menu_transactions;
import Models.menus;
import Models.paymentmodes;
import Models.staffDetails;
import Utilities.UtData;
import java.sql.CallableStatement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class FingerDB {

    private static final String tableName = "staff";
    private static final String userColumn = "staff_id";
    private static final String print1Column = "staff_print11";
    private static final String print2Column = "staff_print12";

    private String URL = "jdbc:mysql://127.0.0.1:3307/";
    //private String URL = "";
    private final String host;
    private final String database;
    private final String userName;
    private final String pwd;
    private Connection connection = null;
    private final String preppedStmtInsert = null;
    private final String preppedStmtUpdate = null;

    private static final String totalStaffQuery = "SELECT * FROM STAFF WHERE "
            + "staff_status = 1";
//    private static final String updateFingerPrintQuery = "UPDATE STAFF SET "
//            + "staff_print11 = ?, staff_print12 = ?, staff_print21 = ?, "
//            + "staff_print22 = ? WHERE staff_id = ?";
//    
    private static final String updateFingerPrintQuery = "UPDATE STAFF SET "
            + "staff_print11 = ?, staff_print12 = ? WHERE staff_id = ?";
    private static final String updateFingerPrint = "UPDATE STAFF SET "
            + "staff_print11 = ?, staff_print12 = ? WHERE staff_id = ?";
    private static final String updateCardNoQuery = "UPDATE STAFF SET "
            + "staff_id_old = ? WHERE staff_id = ?";
    private static final String menuTimeQuery = "SELECT * FROM menus WHERE ? "
            + "BETWEEN start_hour AND end_hour AND ? BETWEEN  from_date AND to_date ";
    private static final String menuTimeQueryByCategory = "SELECT * FROM menus WHERE ? "
            + "BETWEEN start_hour AND end_hour AND ? BETWEEN  from_date AND to_date AND cat_id= ?";

    private static final String staffDetailsQuery = "SELECT staff_name, departments.d_name "
            + "FROM staff INNER JOIN departments ON  departments.d_id = staff.staff_dep "
            + "WHERE staff.staff_id=?";
    private static final String guestInfoQuery = "SELECT dbd.booking_id,"
            + "dbd.guest_name,dbd.guest_pin,dbd.guest_id, db.menu_id,"
            + "me.menu_name,me.menu_price,me.discount_amt,st.staff_id,"
            + "st.staff_name,d.d_name FROM zarida.`department_booking_details` "
            + "dbd LEFT JOIN zarida.`department_bookings` db ON "
            + "dbd.`booking_id` = db.`booking_id` LEFT JOIN zarida.`menus` me "
            + "on db.`menu_id` = me.`menu_id` LEFT JOIN zarida.`staff` st"
            + " ON db.`booked_by` = st.`staff_id` LEFT JOIN zarida.`departments` "
            + "d ON st.`staff_dep` = d.`d_id` WHERE dbd.guest_pin = ? AND "
            + "CURRENT_DATE BETWEEN dbd.`date_from` AND dbd.`date_to` AND "
            + "dbd.guest_id NOT IN (SELECT mt.`booking_id` FROM "
            + "`menu_transactions` mt WHERE DATE(mt.`trans_time`) = CURRENT_DATE)";

    private static final String regMenuTransQuery = "INSERT INTO "
            + "menu_transactions(staff_id,menu_id,meal_cost,discount_amt,"
            + "paid_amt,payment_method,receipt_no,booking_id) "
            + "VALUES(?,?,?,?,?,?,?,?)";
    private static final String updateGuestUsedQuery = "UPDATE "
            + "department_booking_details SET used = 1, used_on = "
            + "NOW() WHERE guest_pin = ?";
    private static final String updatePhoneNumberQuery = "UPDATE staff SET "
            + "staff_phone = ? WHERE staff_id = ?";
    private static final String selectStaffQuery = "SELECT * FROM staff WHERE "
            + "staff_id = ?";
    private static final String checkStaffCountQuery = "SELECT COUNT(*) from "
            + "staff WHERE staff_status = 1";
    private static final String generateReceiptQuery = "SELECT "
            + "zarida.genReceipt(DAYOFWEEK(CURRENT_DATE)) AS receiptno";
    private static final String getCompanyNameQuery = "SELECT "
            + "c_name from companies";
    private static final String checkFloatAccExists = "SELECT * FROM "
            + "float_accounts WHERE fl_acc_no = ?";
    private static final String regFloatTransQuery = "INSERT INTO "
            + "float_transactions(fl_acc_no,fl_receipt,fl_amt_kes,"
            + "fl_trans_date,fl_trans_time,fl_prev_amtkes,fl_balaceskes) "
            + "VALUES(?,?,?,?,?,?,?)";
    private static final String updateFloatAccountsQuery = "UPDATE float_accounts "
            + "SET fl_acc_current= ? WHERE fl_acc_no = ?";
    private static final String paymentMethodsQuery = "SELECT * FROM "
            + "payment_methods WHERE status = 1 and id=5 or id=6";

    public class Record {

        String userID;
        byte[] fmdBinary;

        Record(String ID, byte[] fmd) {
            userID = ID;
            fmdBinary = fmd;
        }
    }

    public FingerDB(String _host, String db, String user, String password) {
        database = db;
        userName = user;
        pwd = password;
        host = _host;

        URL = "jdbc:mysql://" + host + ":3307/";
        
        
    }

    @Override
    public void finalize() {
        try {
            connection.close();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public void Open() throws SQLException {

//        try {
//            Class.forName("com.mysql.jdbc.Driver");
//        } catch (ClassNotFoundException ex) {
//            Logger.getLogger(FingerDB.class.getName()).log(Level.SEVERE, null, ex);
//        }

        connection = DriverManager.getConnection(URL + database, userName, pwd);

    }

    public void Close() throws SQLException {
        connection.close();
    }

    public boolean UserExists(String userID) throws SQLException {
        String sqlStmt = "Select " + userColumn + " from " + tableName
                + " WHERE " + userColumn + "='" + userID + "'";
        Statement st = connection.createStatement();
        ResultSet rs = st.executeQuery(sqlStmt);
        return rs.next();
    }

    public void Insert(String userID, byte[] print1) throws SQLException {
        java.sql.PreparedStatement pst = connection
                .prepareStatement(preppedStmtInsert);
        pst.setString(1, userID);
        pst.setBytes(2, print1);
        pst.execute();
    }

    public void Update(String userID, byte[] print1) throws SQLException {
        PreparedStatement pst = connection
                .prepareStatement(updateFingerPrintQuery);

        pst.setBytes(1, print1);
        pst.setBytes(2, print1);
        pst.setString(3, userID);
        pst.execute();
    }

    public void Update(String userID, String print1) throws SQLException {
        PreparedStatement pst = connection
                .prepareStatement(updateFingerPrint);

        pst.setString(1, print1);
        pst.setString(2, print1);
        pst.setString(3, userID);
        pst.execute();
    }

    public void Insert(String userID, String print1) throws SQLException {
        java.sql.PreparedStatement pst = connection
                .prepareStatement(preppedStmtInsert);
        pst.setString(1, userID);
        pst.setString(2, print1);
        pst.execute();
    }

    public List<Record> GetAllFPData() throws SQLException {
        List<Record> listUsers = new ArrayList<>();
        String sqlStmt = "Select * from " + tableName;
        System.out.println(sqlStmt);
        Statement st = connection.createStatement();
        ResultSet rs = st.executeQuery(sqlStmt);
        while (rs.next()) {
            if (rs.getBytes(print1Column) != null) {
                listUsers.add(new Record(rs.getString(userColumn), rs
                        .getBytes(print1Column)));
            }
        }
        return listUsers;
    }

    public boolean checkuser_id(String staff_id) throws SQLException {
        boolean user_exists = false;
        String sqlStmt = "Select count(*)as no_of_rows from " + tableName + " Where Staff_id='" + staff_id + "'";
        Statement st = connection.createStatement();
        ResultSet rs = st.executeQuery(sqlStmt);
        while (rs.next()) {
            if (rs.getInt("no_of_rows") > 0) {
                user_exists = true;
            }
        }
        return user_exists;
    }
    
    
    public boolean check_float_utilized(String staff_id,String trans_time) throws SQLException {
        boolean trans_exists=  false;
        String sqlStmt = "Select count(*)as no_of_rows from menu_transactions Where Staff_id='" + staff_id + "' AND payment_method = '5' AND DATE(trans_time) ='"+trans_time+"'";
        Statement st = connection.createStatement();
        ResultSet rs = st.executeQuery(sqlStmt);
        while (rs.next()) 
        {
            if (rs.getInt("no_of_rows") > 0) {
                trans_exists = true;
            }
        }
        return trans_exists;
    }

    public boolean checkuser_print(String staff_id) throws SQLException {
        boolean user_print_exists = false;
        String sqlStmt = "Select count(*) as no_of_rows from " + tableName + "Where " + print1Column + " is Null And staff_id='" + staff_id + "'";
        Statement st = connection.createStatement();
        ResultSet rs = st.executeQuery(sqlStmt);
        while (rs.next()) {
            if (rs.getInt("no_of_rows") > 0) {
                user_print_exists = true;
            }
        }
        return user_print_exists;
    }

    public String generateReceipt() {
        String res = null;

        //Connection conn = getConnection();
        // App.logger.info("Query get receipt : "+generateReceiptQuery);
        if (connection != null) {
            Statement stmt = null;
            try {
                stmt = connection.createStatement();
                ResultSet rs = stmt.executeQuery(generateReceiptQuery);
                if (rs.next()) {
                    res = rs.getString("receiptno");
                }

            } catch (SQLException ex) {
                App.logger.log(Level.SEVERE, "Error in generating receipt: {0}", ex.getMessage());
            }

//            try {
//                Close();
//            } catch (SQLException ex) {
//                
//                App.logger.info(ex);
//            }
        } else {
            App.logger.info("DB Connection not available");
        }

        return res;
    }




public Double Utilized_discount_amount(String date,String staff_no) {
        double discount_amt = 0;

        //Connection conn = getConnection();
        // App.logger.info("Query get receipt : "+generateReceiptQuery);
        if (connection != null) {
            Statement stmt = null;
            try {
                stmt = connection.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT SUM(discount_amt) As total_discount FROM menu_transactions WHERE DATE(trans_time)='"+date+"' AND staff_id='"+staff_no+"'");
                if (rs.next()) {
                    discount_amt = rs.getDouble("total_discount");
                }

            } catch (SQLException ex) {
                App.logger.log(Level.SEVERE, "Error in Calculating dicount Summation: {0}", ex.getMessage());
            }

//            try {
//                Close();
//            } catch (SQLException ex) {
//                
//                App.logger.info(ex);
//            }
        } else {
            App.logger.info("DB Connection not available");
        }
        
     

        return discount_amt;
    }




    public String getCompany_name() {
        String res = null;

        //Connection conn = getConnection();
        // App.logger.info("Query get receipt : "+generateReceiptQuery);
        if (connection != null) {
            Statement stmt;
            try {
                stmt = connection.createStatement();
                ResultSet rs = stmt.executeQuery(getCompanyNameQuery);
                if (rs.next()) {
                    res = rs.getString("c_name");
                }

            } catch (SQLException ex) {
                App.logger.log(Level.SEVERE, "Error in generating Company NAme: {0}", ex.getMessage());
            }

//            try {
//                Close();
//            } catch (SQLException ex) {
//                
//                App.logger.info(ex);
//            }
        } else {
            App.logger.info("DB Connection not available");
        }

        App.logger.log(Level.INFO, "Company Name {0}", res);

        return res;
    }

    public String get_payment_method_ID(String payment_method) {
        String res = null;

        //Connection conn = getConnection();
        // App.logger.info("Query get receipt : "+generateReceiptQuery);
        if (connection != null) {
            Statement stmt;
            try {
                String paymentMethodIDQuery = "SELECT id FROM "
                        + "payment_methods WHERE name = '" + payment_method + "'";
                stmt = connection.createStatement();
                ResultSet rs = stmt.executeQuery(paymentMethodIDQuery);
                if (rs.next()) {
                    res = rs.getString("id");
                }

            } catch (SQLException ex) {
                App.logger.log(Level.SEVERE, "Error in generating Payment Method ID: {0}", ex.getMessage());
            }

//            try {
//                Close();
//            } catch (SQLException ex) {
//                
//                App.logger.info(ex);
//            }
        } else {
            App.logger.info("DB Connection not available");
        }

        App.logger.log(Level.INFO, "ID {0}", res);

        return res;
    }

    public String generateReceipt2() {
        String res = null;

        //Connection conn = getConnection();
        // App.logger.info("Query get receipt : "+generateReceiptQuery);
        if (connection != null) {
//            Statement stmt = null;
            try {
//                stmt = connection.createStatement();
//                ResultSet rs = stmt.executeQuery(generateReceiptQuery);
//                if (rs.next()) {
//                    res = rs.getString("receiptno");
//                }
//                
                DriverManager.registerDriver(new com.mysql.jdbc.Driver());

                CallableStatement cstmt = connection.prepareCall("{call genReceipt(?)}");
                //Registering the out parameter of the function (return type)
                cstmt.registerOutParameter(1, Types.VARCHAR);
                //Setting the input parameters of the function
                cstmt.setString(2, "Amit");
                //Executing the statement

                cstmt.execute();

                res = cstmt.getString(1);

            } catch (SQLException ex) {
                //  App.logger.error("Error in generating receipt: "
                //         + ex.getMessage());
            }

            try {
                Close();
            } catch (SQLException ex) {

                // App.logger.info(ex);
            }
        } else {
            //  App.logger.info("DB Connection not available");
        }

        return res;
    }

    public guest_info getGuestInfoFromPin(String guestPin) {
        guest_info selectGuest = null;

        if (connection != null) {
            PreparedStatement pstmt = null;
            try {
                pstmt = connection.prepareStatement(guestInfoQuery);
                pstmt.setString(1, guestPin);

                ResultSet rs = pstmt.executeQuery();

                if (rs.next()) {
                    selectGuest = new guest_info();
                    selectGuest.setBooking_id(rs.getInt("booking_id"));
                    selectGuest.setGuest_name(rs.getString("guest_name"));
                    selectGuest.setGuest_pin(rs.getString("guest_pin"));
                    selectGuest.setMenu_id(rs.getInt("menu_id"));
                    selectGuest.setMenu_name(rs.getString("menu_name"));
                    selectGuest.setMenu_price(rs.getDouble("menu_price"));
                    selectGuest.setDiscount_amt(rs.getDouble("discount_amt"));
                    selectGuest.setStaff_id(rs.getString("staff_id"));
                    selectGuest.setStaff_name(rs.getString("staff_name"));
                    selectGuest.setD_name(rs.getString("d_name"));
                }

            } catch (SQLException ex) {
                App.logger.log(Level.SEVERE, "Error in getting guest info: {0}", ex.getMessage());
            }

            // closeConnection(pstmt, conn);
        } else {
            App.logger.info("DB Connection not available");
        }

        return selectGuest;
    }
//    

    public boolean updateGuestUsed(String guestPin) {
        boolean res = false;

        // Connection conn = getConnection();
        if (connection != null) {
            PreparedStatement pstmt = null;
            try {
                pstmt = connection.prepareStatement(updateGuestUsedQuery);

                pstmt.setString(1, guestPin);

                pstmt.executeUpdate();
                res = true;

            } catch (SQLException ex) {
                App.logger.log(Level.SEVERE, "Error in updating guest used: {0}", ex.getMessage());
            }

            try {
                connection.close();
            } catch (SQLException ex) {
                Logger.getLogger(FingerDB.class.getName()).log(Level.SEVERE, null, ex);
            }

        } else {
            App.logger.info("DB Connection not available");
        }

        return res;
    }

    public List<menus> getMenuList() {
        List<menus> menuList = null;

        int selectedHour = LocalDateTime.now().getHour();

        //int selectedHour = LocalDateTime.now().getHour();
        String currentdate = new SimpleDateFormat("yyyy-MM-dd").format(new java.util.Date());
        //Connection conn = getConnection();
        if (connection != null) {
            PreparedStatement pstmt = null;
            try {
                pstmt = connection.prepareStatement(menuTimeQuery);
                pstmt.setInt(1, selectedHour);
                pstmt.setString(2, currentdate);

                ResultSet rs = pstmt.executeQuery();
                menuList = new ArrayList<>();
                while (rs.next()) {

                    menus m = new menus();
                    m.setMenu_id(rs.getInt("menu_id"));
                    m.setMenu_name(rs.getString("menu_name"));
                    m.setStart_hour(rs.getInt("start_hour"));
                    m.setEnd_hour(rs.getInt("end_hour"));
                    m.setMenu_price(rs.getDouble("menu_price"));
                    m.setDiscountable(rs.getInt("discountable"));
                    m.setDiscount_amt(rs.getDouble("discount_amt"));

                    menuList.add(m);
                }
            } catch (SQLException ex) {
                App.logger.log(Level.INFO, "Error in getting menu list: {0}", ex.getMessage());
            }

//            try {
//                Close();
//            } catch (SQLException ex) {
//                Logger.getLogger(FingerDB.class.getName()).log(Level.SEVERE, null, ex);
//            }
        } else {
            App.logger.info("DB Connection not available");
        }

        return menuList;
    }

    
     public List<categories> getCategoryList() {
        List<categories> menuList = null;

        
        if (connection != null) {
            PreparedStatement pstmt ;
            try {
                pstmt = connection.prepareStatement("Select * from menu_categories");
                
                ResultSet rs = pstmt.executeQuery();
                menuList = new ArrayList<>();
                while (rs.next()) {

                    categories m = new categories();
                    m.setCategory_id(rs.getInt("cat_id"));
                    m.setCategory_name(rs.getString("cat_name"));
                    

                    menuList.add(m);
                }
            } catch (SQLException ex) {
                App.logger.log(Level.INFO, "Error in getting Categories list: {0}", ex.getMessage());
            }

//            try {
//                Close();
//            } catch (SQLException ex) {
//                Logger.getLogger(FingerDB.class.getName()).log(Level.SEVERE, null, ex);
//            }
        } else {
            App.logger.info("DB Connection not available");
        }

        return menuList;
    }
    
     
     
    public void add_menu_item_to_cart(String menu_item, int quantity, JTable table) {
    
    DefaultTableModel model = (DefaultTableModel) table.getModel();

    table.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
    table.setDefaultRenderer(Object.class, new Render());
    JButton cmdRemove = new JButton("Remove");

    if (connection != null) {
        String query = "SELECT menu_price,menu_id FROM menus WHERE menu_name = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, menu_item);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    String menu_id =rs.getString("menu_id");
                    double menu_price = rs.getDouble("menu_price");
                    double total = quantity * menu_price;

                    model.addRow(new Object[]{menu_item, menu_price, quantity, total, cmdRemove, 0,menu_id,0});

                    
//                    UtData.SELECTED_MENU_ITEMS.add(new Items(menu_item, menu_price, quantity, total, null, 0));
//
//                    System.out.println(UtData.SELECTED_MENU_ITEMS.size());
                }
            }
        } catch (SQLException ex) {
            App.logger.log(Level.SEVERE, "Error loading Cart Table: {0}", ex.getMessage());
        }
    } else {
        App.logger.severe("DB Connection not available");
    }
}

  
    
    public void getMenuList_by_category(String Cat_id,JComboBox<String> cmbmenu) {
       

        int selectedHour = LocalDateTime.now().getHour();

        
      
        //int selectedHour = LocalDateTime.now().getHour();
        String currentdate = new SimpleDateFormat("yyyy-MM-dd").format(new java.util.Date());
        //Connection conn = getConnection();
        if (connection != null) {
            PreparedStatement pstmt;
            try {
                pstmt = connection.prepareStatement(menuTimeQueryByCategory);
                pstmt.setInt(1, selectedHour);
                pstmt.setString(2, currentdate);
                pstmt.setString(3, Cat_id);

                ResultSet rs = pstmt.executeQuery();
               
                while (rs.next()) {

                
                    
                  
                     String menu_name=(rs.getString("menu_name"));
                    
                   cmbmenu.addItem(menu_name);
                   
                }
            } catch (SQLException ex) {
                App.logger.log(Level.INFO, "Error loading Combobox Item List: {0}", ex.getMessage());
            }

//            try {
//                Close();
//            } catch (SQLException ex) {
//                Logger.getLogger(FingerDB.class.getName()).log(Level.SEVERE, null, ex);
//            }
        } else {
            App.logger.info("DB Connection not available");
        }

      
    }

  
    
    
    
     public String get_menu_Cat_ID(String category_name) {
        String res = null;

        //Connection conn = getConnection();
        // App.logger.info("Query get receipt : "+generateReceiptQuery);
        if (connection != null) {
            Statement stmt;
            try {
                String CategoryIDQuery = "SELECT cat_id FROM "
                        + "menu_categories WHERE cat_name = '" + category_name + "'";
                stmt = connection.createStatement();
                ResultSet rs = stmt.executeQuery(CategoryIDQuery);
                if (rs.next()) {
                    res = rs.getString("cat_id");
                }

            } catch (SQLException ex) {
                App.logger.log(Level.SEVERE, "Error in generating Menu Category ID: {0}", ex.getMessage());
            }

//            try {
//                Close();
//            } catch (SQLException ex) {
//                
//                App.logger.info(ex);
//            }
        } else {
            App.logger.info("DB Connection not available");
        }

        App.logger.log(Level.INFO, "ID {0}", res);

        return res;
    }
    
    public List<paymentmodes> get_payment_modes() {
        List<paymentmodes> modes_list = null;

        //Connection conn = getConnection();
        if (connection != null) {
            PreparedStatement pstmt = null;
            try {
                pstmt = connection.prepareStatement(paymentMethodsQuery);

                ResultSet rs = pstmt.executeQuery();
                modes_list = new ArrayList<>();
                while (rs.next()) {

                    paymentmodes m = new paymentmodes();
                    m.setMethod_name(rs.getString("name"));

                    m.setStatus(rs.getInt("status"));

                    modes_list.add(m);
                }
            } catch (SQLException ex) {
                App.logger.log(Level.INFO, "Error in getting payment modes list: {0}", ex.getMessage());
            }

//            try {
//                Close();
//            } catch (SQLException ex) {
//                Logger.getLogger(FingerDB.class.getName()).log(Level.SEVERE, null, ex);
//            }
        } else {
            App.logger.info("DB Connection not available");
        }

        return modes_list;
    }

    
     public List<paymentmodes> get_cash_payment_mode() {
        List<paymentmodes> modes_list = null;

        //Connection conn = getConnection();
        if (connection != null) {
            PreparedStatement pstmt = null;
            try {
                pstmt = connection.prepareStatement("Select name, status from payment_methods where id=6");

                ResultSet rs = pstmt.executeQuery();
                modes_list = new ArrayList<>();
                while (rs.next()) {

                    paymentmodes m = new paymentmodes();
                    m.setMethod_name(rs.getString("name"));

                    m.setStatus(rs.getInt("status"));

                    modes_list.add(m);
                }
            } catch (SQLException ex) {
                App.logger.log(Level.INFO, "Error in getting payment modes list: {0}", ex.getMessage());
            }

//            try {
//                Close();
//            } catch (SQLException ex) {
//                Logger.getLogger(FingerDB.class.getName()).log(Level.SEVERE, null, ex);
//            }
        } else {
            App.logger.info("DB Connection not available");
        }

        return modes_list;
    }
    
    public List<staffDetails> getStaffDetails(String Staff_id) {
        List<staffDetails> Staff_details = null;

        //Connection conn = getConnection();
        if (connection != null) {
            PreparedStatement pstmt = null;
            try {
                pstmt = connection.prepareStatement(staffDetailsQuery);
                pstmt.setString(1, Staff_id);

                ResultSet rs = pstmt.executeQuery();
                Staff_details = new ArrayList<>();
                while (rs.next()) {

                    staffDetails m = new staffDetails();
                    m.setStaffName(rs.getString("staff_name"));
                    m.setStaffDepartment(rs.getString("departments.d_name"));
                    m.setStaffID(Staff_id);

                    Staff_details.add(m);
                }
            } catch (SQLException ex) {
                App.logger.log(Level.SEVERE, "Error in getting Staff Details list: {0}", ex.getMessage());
            }

//            try {
//                Close();
//            } catch (SQLException ex) {
//                Logger.getLogger(FingerDB.class.getName()).log(Level.SEVERE, null, ex);
//            }
        } else {
            App.logger.info("DB Connection not available");
        }

        return Staff_details;
    }

//	public String GetConnectionString() {
//		return URL + " User: " + this.userName;
//	}
//
//	public String GetExpectedTableSchema() {
//		return "Table: " + tableName + " PK(VARCHAR(32)): " + userColumn
//				+ "VARBINARY(4000): " + print1Column;
//	}
    public boolean insertMenuTransaction(menu_transactions mtr) {
        boolean res = false;

        // Connection conn = getConnection();
        if (connection != null) {
            PreparedStatement pstmt = null;
            try {
                pstmt = connection.prepareStatement(regMenuTransQuery);

                pstmt.setString(1, mtr.getStaff_id());
                pstmt.setInt(2, mtr.getMenu_id());
                pstmt.setDouble(3, mtr.getMeal_cost());
                pstmt.setDouble(4, mtr.getDiscount_amt());
                pstmt.setDouble(5, mtr.getPaid_amt());
                pstmt.setInt(6, mtr.getPayment_method());
                pstmt.setString(7, mtr.getReceipt_no());
                pstmt.setInt(8, mtr.getBooking_id());

                pstmt.executeUpdate();
                res = true;

            } catch (SQLException ex) {
                App.logger.log(Level.INFO, "Error in registering menu transaction: {0}", ex.getMessage());
                //ex.printStackTrace();
            }

            // closeConnection(pstmt, connection);
        } else {
            App.logger.info("DB Connection not available");
        }

        return res;
    }

    public boolean insertMenuTransaction(String Staff_id,
            int menu_id,
            double Meal_cost,
            double Disc_amt,
            double paid_amt,
            int payMode,
            String Receipt_No,
            int Booking_id) {
        boolean res = false;

        // Connection conn = getConnection();
        if (connection != null) {
            PreparedStatement pstmt;
            try {
                pstmt = connection.prepareStatement(regMenuTransQuery);

                pstmt.setString(1, Staff_id);
                pstmt.setInt(2, menu_id);
                pstmt.setDouble(3, Meal_cost);
                pstmt.setDouble(4, Disc_amt);
                pstmt.setDouble(5, paid_amt);
                pstmt.setInt(6, payMode);
                pstmt.setString(7, Receipt_No);
                pstmt.setInt(8, Booking_id);

                pstmt.executeUpdate();
                res = true;

            } catch (SQLException ex) {
                App.logger.log(Level.INFO, "Error in registering menu transaction: {0}", ex.getMessage());
                //ex.printStackTrace();
            }

            // closeConnection(pstmt, connection);
        } else {
            App.logger.info("DB Connection not available");
        }

        return res;
    }

}
