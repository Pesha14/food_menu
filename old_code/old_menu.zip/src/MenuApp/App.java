/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package MenuApp;

import MenuApp.Enrollment_.EnrollmentThread;

import Models.BillPrintable;
import Models.Items;
import Models.categories;
import Models.guest_info;
import Models.menus;
import Models.paymentmodes;
import Models.staffDetails;
import Utilities.Elogger;
import Utilities.UtData;
import com.digitalpersona.uareu.Engine;
import com.digitalpersona.uareu.Fid;
import com.digitalpersona.uareu.Fmd;
import com.digitalpersona.uareu.Reader;
import com.digitalpersona.uareu.ReaderCollection;
import com.digitalpersona.uareu.UareUException;
import com.digitalpersona.uareu.UareUGlobal;
import com.formdev.flatlaf.fonts.roboto.FlatRobotoFont;
import com.formdev.flatlaf.intellijthemes.FlatArcOrangeIJTheme;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Toolkit;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.PageFormat;
import java.awt.print.Paper;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import javax.print.PrintServiceLookup;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.Timer;
import javax.swing.table.DefaultTableModel;

import java.util.logging.*;
import javax.print.PrintService;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JToggleButton;
import javax.swing.SwingConstants;
import javax.swing.SwingWorker;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableCellRenderer;
import raven.cell.TableActionCellEditor;
import raven.cell.TableActionCellRender;
import raven.cell.TableActionEvent;

/**
 *
 * @author USER
 */
public final class App extends javax.swing.JFrame implements ActionListener {
    // public javax.swing.JPanel myContentPane;

    /**
     * Creates new form MainFrame
     */
    public static Fmd GlobalFMD;
    //verification start Copy
    static int clickcount = 0;
    private static final long serialVersionUID = 6;
    private static final String ACT_BACK = "back";
    private static final String ACT_LOAD = "load";
    private static final String ACT_LOAD_FROM_DB = "load_from_db";
    private boolean hardware_initialized = false;
    private CaptureThread m_capture;
    private final EnrollmentThread m_enrollment;
    //private Reader m_reader;
    private Fmd[] m_fmds;
    private JDialog m_dlgParent;
    public FingerDB db = new FingerDB("127.0.0.1", "zarida", "root", "root");
    public List<FingerDB.Record> m_listOfRecords = new ArrayList<>();
    public List<Fmd> m_fmdList = new ArrayList<>();
    public Fmd[] m_fmdArray = null; // Will hold final array of FMDs to identify
    // against
    private JTextArea m_text_;
    public Fmd m_enrollmentFmd;
    private ImagePanel m_imagePanel;

    ArrayList<String> SELECTED_ITEM_MENU = new ArrayList<>();
    ArrayList<Double> SELECTED_ITEM_COST = new ArrayList<>();
    private final String m_strPrompt1 = "Present Your Finger to Scan";
    private final String m_strPrompt2 = "Put the same or any other finger on the reader";

    //verification End Copy 
    //  public static final Logger logger = LogManager.getLogger(App.class);
    private static ReaderCollection m_collection;
    private static Reader m_reader;

    private boolean m_bJustStarted;
    private boolean save_data;
    public String ENROLLMENT_MESSAGE = "";

    private String COMPANY_NAME = "";
    private String ADDRESS = "";
    private String TELEPHONE = "";
    private String RECEIPT_NO = "";
    private String STAFF_ID = "";
    private String STAFF_NAME = "";
    private String STAFF_DEPARTMENT = "";
    private String MENU = "";
    private double AMOUNT_TO_PAY;
    private double DISCOUNT_AMOUNT;
    private double DISCOUNT_AMOUNT_PAID;
     private double CASH_AMOUNT;
    
    static int NO_OF_SELECTED_MENU_ITEMS=1;
    
        

    public final static Logger logger = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);

    public static Elogger elogger = new Elogger();
    
   String today = new SimpleDateFormat("yyyy-MM-dd").format(new java.util.Date());
   
   
    public App() {

        this.setUndecorated(true);
        this.setAlwaysOnTop(true);
        this.setResizable(false);
        initComponents();
        
        
        //setVisible(true);
//MenuTabs2.setBackgroundAt(0, Color.darkGray);
//MenuTabs2.setBackgroundAt(1, Color.black);
//UIManager.put("TabbedPane.selected", Color.gray);
//        
        Toolkit tk = Toolkit.getDefaultToolkit();
        int xsize = (int) tk.getScreenSize().getWidth();
        int ysize = (int) tk.getScreenSize().getHeight();

        this.setSize(xsize, ysize);
        setupLogger();
        // m_imagePanel = new ImagePanel();
        try {
            // add(m_imagePanel,BorderLayout.CENTER);
            // setVisible(true);
            db.Open();
            elogger.debug("DB Connection Successful");
        } catch (SQLException ex) {
            
            elogger.error("Error Connecting to DB", ex);
            logger.log(Level.SEVERE, ex.getMessage());
            Logger.getLogger(App.class.getName()).log(Level.SEVERE, null, ex);
        }
        load_date_time();

        m_fmds = new Fmd[2];
        load_templates_from_db();

        m_bJustStarted = true;

        m_enrollment = null;
        //

        Initialize_Reader();

        hide_menu();

        COMPANY_NAME = db.getCompany_name();
        
       

        // startVerification(m_reader);
        
//        MenuTabs2.setVisible(true);
//        
//        load_menu("1018");



TableActionEvent event = new TableActionEvent() {
            @Override
            public void onEdit(int row) {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }

            @Override
            public void onDelete(int row) {
             if (tblcart_items.isEditing()) {
                    tblcart_items.getCellEditor().stopCellEditing();
                    
                  
                }
                DefaultTableModel model = (DefaultTableModel) tblcart_items.getModel();
                model.removeRow(row);   
           DiscountDistributorSequential();
            
            }

            @Override
            public void onView(int row) {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }
        };

 tblcart_items.getColumnModel().getColumn(4).setCellRenderer(new TableActionCellRender());
        tblcart_items.getColumnModel().getColumn(4).setCellEditor(new TableActionCellEditor(event));
        tblcart_items.getColumnModel().getColumn(0).setCellRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable jtable, Object o, boolean bln, boolean bln1, int i, int i1) {
                setHorizontalAlignment(SwingConstants.RIGHT);
                return super.getTableCellRendererComponent(jtable, o, bln, bln1, i, i1);
            }
        });
    }

    private static void setupLogger() {

        //create logs Directory
        try {

            Path path = Paths.get("Logs");

            Files.createDirectories(path);

//            File f = new File("Logs/log.log");
//if (!f.exists() && !f.mkdirs()) throw new IOException("Could not create directory " + f);
//      
        } catch (IOException e) {

        }

        SimpleDateFormat dateFormat
                = new SimpleDateFormat("ddMMMyyyyH");

        Calendar currentCalendar = Calendar.getInstance();
        Date currentTime = currentCalendar.getTime();

        String dateString = dateFormat.format(currentTime);
        LogManager.getLogManager().reset();
        logger.setLevel(Level.ALL);

        ConsoleHandler ch = new ConsoleHandler();
        ch.setLevel(Level.SEVERE);
        logger.addHandler(ch);

        try {

            FileHandler fh = new FileHandler("logs/" + dateString + "_Log.log", true);
            fh.setLevel(Level.ALL);

            logger.addHandler(fh);
        } catch (java.io.IOException e) {
            // don't stop my program but log out to console.
            logger.log(Level.SEVERE, "File logger not working.", e);
        }
        /* 
         Different Levels in order.
          OFF
          SEVERE
          WARNING
          INFO
          CONFIG
          FINE
          FINER
          FINEST
          ALL
         /* 
         Different Levels in order.
          OFF
          SEVERE
          WARNING
          INFO
          CONFIG
          FINE
          FINER
          FINEST
          ALL
         */
    }

    public void hide_menu() {

        //tblmenu_scrollPane.setVisible(false);
        //lblmenu.setVisible(false);
        cmdstart.setVisible(false);
        lblprogress.setVisible(false);
        txtid.setVisible(false);
        cmd_enroll.setVisible(false);
        main_separator.setVisible(false);
        //fprint_scrollpane.setVisible(false);
        cmdback.setVisible(false);
        txt_staff_pin.setVisible(false);
        Paymentmode_panel.setVisible(false);
          MenuPanel.setVisible(false);
          keyboard_panel.setVisible(false);
          MenuTabs2.setVisible(false);
          Menu_select_panel.setVisible(false);

    }

    void show_menu() {
        tblmenu_scrollPane.setVisible(true);
        lblmenu.setVisible(true);
        cmdstart.setVisible(true);

    }

    void reset() {
        try {
            DefaultTableModel model = (DefaultTableModel) tblmenu.getModel();

            while (model.getRowCount() > 0) {
                model.removeRow(0);
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        
        
        
        try {
            DefaultTableModel model = (DefaultTableModel) tblcart_items.getModel();

            while (model.getRowCount() > 0) {
                model.removeRow(0);
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
//Clear the Selected Item Array
        if (!SELECTED_ITEM_MENU.isEmpty()) {

            SELECTED_ITEM_MENU.clear();

        }

        if (!SELECTED_ITEM_COST.isEmpty()) {

            SELECTED_ITEM_COST.clear();
        }

        AMOUNT_TO_PAY = 0;
        MenuPanel.removeAll();

        MenuPanel.updateUI();
        Paymentmode_panel.removeAll();

        Paymentmode_panel.updateUI();
        
        MenuCategories.removeAll();

        MenuCategories.updateUI();
        
        lbl_balance.setText("");

        // load_menu("28466275");
    }

    public void re_initialize_reader() {

        try {

            UareUGlobal.DestroyReaderCollection();
            App.m_collection = null;
            App.m_collection = UareUGlobal.GetReaderCollection();
            m_collection.GetReaders();
        } catch (UareUException e1) {
            // TODO Auto-generated catch block
            //JOptionPane.showMessageDialog(null, "Error getting collection");
            App.logger.info("Error Getting Reader Collection");

            return;
        }

        if (m_collection.isEmpty()) {
            MessageBox.Warning("Reader is not selected");
            App.logger.info("Reader is not selected");
            // System.exit(0);
            return;
        }

        m_reader = m_collection.get(0);

        if (null == m_reader) {
            MessageBox.Warning("Reader is not selected");
            App.logger.info("Reader is not selected");
        } else {

        }

    }

    public void Initialize_Reader() {

        try {
            App.m_collection = UareUGlobal.GetReaderCollection();
            m_collection.GetReaders();
        } catch (UareUException e1) {
            // TODO Auto-generated catch block
            //JOptionPane.showMessageDialog(null, "Error getting collection");
            App.logger.info("Error Getting Reader Collection");

            return;
        }

        if (m_collection.isEmpty()) {
            MessageBox.Warning("Reader is not selected");
            App.logger.info("Reader is not selected");
            // System.exit(0);
            return;
        }

        m_reader = m_collection.get(0);

        if (null == m_reader) {
            MessageBox.Warning("Reader is not selected");
            App.logger.info("Reader is not selected");
        } else {
            // hardware_initialized= true;

            try {
                m_reader.Open(Reader.Priority.COOPERATIVE);
                startVerification(m_reader);
            } catch (UareUException e) {
                MessageBox.DpError("Reader.Open()", e);
            }

            //Verification.Run(m_reader, this.enrollmentFMD);
        }

    }

    public static void appendToFile(Exception e) {
        try {
            FileWriter New_File = new FileWriter("Error-log.txt", true);
            BufferedWriter Buff_File = new BufferedWriter(New_File);
            PrintWriter Print_File = new PrintWriter(Buff_File, true);
            e.printStackTrace(Print_File);
        } catch (IOException ie) {
            throw new RuntimeException("Cannot write the Exception to file", ie);
        }
    }

    void load_templates_from_db() {

        try {

            db.Open();
            this.m_listOfRecords = db.GetAllFPData();
            for (FingerDB.Record record : this.m_listOfRecords) {

                Fmd fmd
                        = UareUGlobal
                                .GetImporter()
                                .ImportFmd(
                                        record.fmdBinary,
                                        com.digitalpersona.uareu.Fmd.Format.DP_REG_FEATURES,
                                        com.digitalpersona.uareu.Fmd.Format.DP_REG_FEATURES);
                System.out.println(Arrays.toString(fmd.getData()));
                this.m_fmdList.add(fmd);

            }
            m_fmdArray = new Fmd[this.m_fmdList.size()];
            this.m_fmdList.toArray(m_fmdArray);
            logger.log(Level.INFO, "Templates loaded");
            System.out.println(m_fmdList);
            elogger.debug(String.valueOf(m_fmdList));
            m_text.setText("Scan FingerPrint");
        } catch (SQLException e1) {
            // TODO Auto-generated catch block
//				MessageBox
//						.DpError(
//								"Failed to load FMDs from database.  Please check connection string in code.",
//								null);

            appendToFile(e1);
            return;
        } catch (UareUException e1) {
            // TODO Auto-generated catch block
            JOptionPane
                    .showMessageDialog(null, "Error importing fmd data.");
            appendToFile(e1);
            return;
        }

        //	this.m_load.setEnabled(false); // Dont allow user to load fmd from
        // file (confusing).
        this.m_enrollmentFmd = null;

    }

    void reload_templates_from_db() {

        try {
            m_listOfRecords.clear();
            this.m_fmdList.clear();

            db.Open();
            this.m_listOfRecords = db.GetAllFPData();
            for (FingerDB.Record record : this.m_listOfRecords) {

                Fmd fmd
                        = UareUGlobal
                                .GetImporter()
                                .ImportFmd(
                                        record.fmdBinary,
                                        com.digitalpersona.uareu.Fmd.Format.DP_REG_FEATURES,
                                        com.digitalpersona.uareu.Fmd.Format.DP_REG_FEATURES);
                System.out.println(Arrays.toString(fmd.getData()));
                this.m_fmdList.add(fmd);

            }
            m_fmdArray = new Fmd[this.m_fmdList.size()];
            this.m_fmdList.toArray(m_fmdArray);
            logger.log(Level.INFO, "Templates loaded");
            System.out.println(m_fmdList);
            m_text.setText("Scan FingerPrint");
        } catch (SQLException e1) {
            // TODO Auto-generated catch block
//				MessageBox
//						.DpError(
//								"Failed to load FMDs from database.  Please check connection string in code.",
//								null);

            appendToFile(e1);
            return;
        } catch (UareUException e1) {
            // TODO Auto-generated catch block
            JOptionPane
                    .showMessageDialog(null, "Error importing fmd data.");
            appendToFile(e1);
            return;
        }

        //	this.m_load.setEnabled(false); // Dont allow user to load fmd from
        // file (confusing).
        this.m_enrollmentFmd = null;

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        cmdverify = new javax.swing.JButton();
        cmdcancel = new javax.swing.JButton();
        fmd_output = new javax.swing.JLabel();
        fprint_scrollpane = new javax.swing.JScrollPane();
        fprint_text = new javax.swing.JTextArea();
        main_separator = new javax.swing.JSeparator();
        MenuPanel = new javax.swing.JPanel();
        MainPanel = new javax.swing.JPanel();
        tblmenu_scrollPane = new javax.swing.JScrollPane();
        tblmenu = new javax.swing.JTable();
        lblmenu = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        myContentPane = new javax.swing.JPanel();
        m_text = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        cmd_enroll = new javax.swing.JButton();
        cmdguest = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        cmdback = new javax.swing.JButton();
        cmdstart = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        txt_staff_pin = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        txtid = new javax.swing.JTextField();
        Paymentmode_panel = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        lblprogress = new javax.swing.JLabel();
        lblststatus1 = new javax.swing.JLabel();
        lbltime_ = new javax.swing.JLabel();
        lbldate = new javax.swing.JLabel();
        lbl_balance = new javax.swing.JLabel();
        keyboard_panel = new javax.swing.JPanel();
        Menu_select_panel = new javax.swing.JPanel();
        cmbitems = new javax.swing.JComboBox<>();
        cmdadd = new javax.swing.JButton();
        cmdminus = new javax.swing.JButton();
        cmd_add_to_cart = new javax.swing.JButton();
        txtqty = new javax.swing.JLabel();
        MenuTabs2 = new javax.swing.JTabbedPane();
        MenuCategories = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        tbltablescroll2 = new javax.swing.JScrollPane();
        tblcart_items = new javax.swing.JTable();

        cmdverify.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        cmdverify.setText("Staff Verification");
        cmdverify.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdverifyActionPerformed(evt);
            }
        });

        cmdcancel.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        cmdcancel.setText("Cancel");
        cmdcancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdcancelActionPerformed(evt);
            }
        });

        fprint_text.setEditable(false);
        fprint_text.setBackground(new java.awt.Color(204, 204, 255));
        fprint_text.setColumns(20);
        fprint_text.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        fprint_text.setRows(5);
        fprint_text.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        fprint_scrollpane.setViewportView(fprint_text);

        main_separator.setOrientation(javax.swing.SwingConstants.VERTICAL);

        MenuPanel.setOpaque(false);
        MenuPanel.setLayout(new java.awt.GridLayout(8, 3));

        MainPanel.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        MainPanel.setOpaque(false);

        tblmenu.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Staff ID", "Menu ID", "Menu Item", "Meal Cost", "Discount", "Total Cost", "Transaction_ID", "Booking ID", "Guest Name", "Guest PIN", "Staff Name", "D Name", "Selected", "Qty"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false, false, false, true, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblmenu.setColumnSelectionAllowed(true);
        tblmenu_scrollPane.setViewportView(tblmenu);
        tblmenu.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);

        lblmenu.setBackground(new java.awt.Color(255, 204, 153));
        lblmenu.setFont(new java.awt.Font("SansSerif", 0, 24)); // NOI18N
        lblmenu.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblmenu.setText("MENU");
        lblmenu.setOpaque(true);

        jButton1.setText("jButton1");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("jButton2");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("jButton3");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout MainPanelLayout = new javax.swing.GroupLayout(MainPanel);
        MainPanel.setLayout(MainPanelLayout);
        MainPanelLayout.setHorizontalGroup(
            MainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MainPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(MainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(tblmenu_scrollPane, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 712, Short.MAX_VALUE)
                    .addComponent(lblmenu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(MainPanelLayout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton2)
                .addGap(18, 18, 18)
                .addComponent(jButton3)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        MainPanelLayout.setVerticalGroup(
            MainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MainPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblmenu, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tblmenu_scrollPane, javax.swing.GroupLayout.DEFAULT_SIZE, 402, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(MainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton3)
                    .addComponent(jButton2)
                    .addComponent(jButton1)))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        myContentPane.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        m_text.setFont(new java.awt.Font("SansSerif", 1, 24)); // NOI18N
        m_text.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        m_text.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/icons8-fingerprint-scan-64.png"))); // NOI18N
        m_text.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                m_textPropertyChange(evt);
            }
        });

        jPanel1.setOpaque(false);
        jPanel1.setLayout(new java.awt.GridLayout(1, 0, 1, 0));

        cmd_enroll.setBackground(new java.awt.Color(204, 204, 255));
        cmd_enroll.setFont(new java.awt.Font("Tahoma", 0, 26)); // NOI18N
        cmd_enroll.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/icons8-add-user-male-64.png"))); // NOI18N
        cmd_enroll.setText("Register");
        cmd_enroll.setBorderPainted(false);
        cmd_enroll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmd_enrollActionPerformed(evt);
            }
        });
        jPanel1.add(cmd_enroll);

        cmdguest.setBackground(new java.awt.Color(204, 204, 255));
        cmdguest.setFont(new java.awt.Font("Tahoma", 0, 26)); // NOI18N
        cmdguest.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/icons8-reception-64.png"))); // NOI18N
        cmdguest.setText("Non Staff");
        cmdguest.setBorderPainted(false);
        cmdguest.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdguestActionPerformed(evt);
            }
        });
        jPanel1.add(cmdguest);

        jPanel2.setOpaque(false);
        jPanel2.setLayout(new java.awt.GridLayout(2, 0, 1, 0));

        cmdback.setBackground(new java.awt.Color(204, 204, 255));
        cmdback.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        cmdback.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/icons8-back-64.png"))); // NOI18N
        cmdback.setText("Back to Start");
        cmdback.setBorderPainted(false);
        cmdback.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdbackActionPerformed(evt);
            }
        });
        jPanel2.add(cmdback);

        cmdstart.setBackground(new java.awt.Color(204, 204, 255));
        cmdstart.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        cmdstart.setText("Start");
        cmdstart.setBorderPainted(false);
        cmdstart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdstartActionPerformed(evt);
            }
        });
        jPanel2.add(cmdstart);

        jPanel3.setOpaque(false);

        txt_staff_pin.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        txt_staff_pin.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_staff_pin.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txt_staff_pinFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_staff_pinFocusLost(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(txt_staff_pin, javax.swing.GroupLayout.PREFERRED_SIZE, 358, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(txt_staff_pin, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 54, Short.MAX_VALUE)
        );

        jPanel4.setOpaque(false);

        txtid.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        txtid.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtid.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtidFocusGained(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(txtid, javax.swing.GroupLayout.PREFERRED_SIZE, 359, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(txtid, javax.swing.GroupLayout.DEFAULT_SIZE, 54, Short.MAX_VALUE)
        );

        Paymentmode_panel.setOpaque(false);
        Paymentmode_panel.setLayout(new java.awt.GridLayout(1, 0));

        jPanel5.setOpaque(false);

        lblprogress.setBackground(new java.awt.Color(153, 153, 255));
        lblprogress.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblprogress.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblprogress.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/770 (3).gif"))); // NOI18N

        lblststatus1.setBackground(new java.awt.Color(153, 153, 255));
        lblststatus1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/menuMain.png"))); // NOI18N

        lbltime_.setFont(new java.awt.Font("SansSerif", 0, 24)); // NOI18N
        lbltime_.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbltime_.setText("Time");

        lbldate.setFont(new java.awt.Font("SansSerif", 0, 24)); // NOI18N
        lbldate.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbldate.setText("Date");

        lbl_balance.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        lbl_balance.setForeground(new java.awt.Color(255, 0, 0));

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblststatus1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblprogress, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lbltime_, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                    .addComponent(lbldate, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lbl_balance, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblststatus1)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblprogress, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(lbldate)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lbltime_)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lbl_balance)))))
                .addContainerGap())
        );

        keyboard_panel.setOpaque(false);
        keyboard_panel.setLayout(new java.awt.GridLayout(4, 0, 5, 5));

        Menu_select_panel.setOpaque(false);

        cmbitems.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        cmbitems.setMaximumRowCount(10);

        cmdadd.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        cmdadd.setText("+");
        cmdadd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdaddActionPerformed(evt);
            }
        });

        cmdminus.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        cmdminus.setText("-");
        cmdminus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdminusActionPerformed(evt);
            }
        });

        cmd_add_to_cart.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/add_to_cart50.png"))); // NOI18N
        cmd_add_to_cart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmd_add_to_cartActionPerformed(evt);
            }
        });

        txtqty.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        txtqty.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        txtqty.setText("1");
        txtqty.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        javax.swing.GroupLayout Menu_select_panelLayout = new javax.swing.GroupLayout(Menu_select_panel);
        Menu_select_panel.setLayout(Menu_select_panelLayout);
        Menu_select_panelLayout.setHorizontalGroup(
            Menu_select_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Menu_select_panelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cmbitems, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(cmd_add_to_cart, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(cmdadd, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cmdminus, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txtqty, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        Menu_select_panelLayout.setVerticalGroup(
            Menu_select_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cmbitems)
            .addComponent(cmd_add_to_cart, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(cmdadd, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(cmdminus, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(txtqty, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        MenuTabs2.setForeground(new java.awt.Color(0, 0, 102));
        MenuTabs2.setTabLayoutPolicy(javax.swing.JTabbedPane.SCROLL_TAB_LAYOUT);
        MenuTabs2.setFont(new java.awt.Font("Roboto Medium", 0, 24)); // NOI18N

        MenuCategories.setOpaque(false);
        MenuCategories.setLayout(new java.awt.GridLayout(8, 3));
        MenuTabs2.addTab("Menu Categories", MenuCategories);

        jPanel8.setBackground(new java.awt.Color(255, 51, 204));
        jPanel8.setOpaque(false);

        tblcart_items.setDefaultRenderer(Object.class, new Render());
        tblcart_items.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        tblcart_items.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Menu Item", "@", "Qty", "Total Cost", "Review", "Discount", "Menu ID", "Cash To Pay"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Double.class, java.lang.Object.class, java.lang.Double.class, java.lang.Object.class, java.lang.Double.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, true, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblcart_items.setOpaque(false);
        tblcart_items.setRowHeight(60);
        tblcart_items.setSelectionBackground(new java.awt.Color(255, 255, 255));
        tblcart_items.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        tblcart_items.setShowGrid(false);
        tblcart_items.getTableHeader().setReorderingAllowed(false);
        tblcart_items.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                tblcart_itemsPropertyChange(evt);
            }
        });
        tbltablescroll2.setViewportView(tblcart_items);
        if (tblcart_items.getColumnModel().getColumnCount() > 0) {
            tblcart_items.getColumnModel().getColumn(0).setMinWidth(300);
            tblcart_items.getColumnModel().getColumn(0).setPreferredWidth(300);
            tblcart_items.getColumnModel().getColumn(0).setMaxWidth(300);
            tblcart_items.getColumnModel().getColumn(6).setMinWidth(0);
            tblcart_items.getColumnModel().getColumn(6).setPreferredWidth(0);
            tblcart_items.getColumnModel().getColumn(6).setMaxWidth(0);
            tblcart_items.getColumnModel().getColumn(7).setMinWidth(0);
            tblcart_items.getColumnModel().getColumn(7).setPreferredWidth(0);
            tblcart_items.getColumnModel().getColumn(7).setMaxWidth(0);
        }

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(tbltablescroll2, javax.swing.GroupLayout.DEFAULT_SIZE, 734, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(tbltablescroll2, javax.swing.GroupLayout.DEFAULT_SIZE, 481, Short.MAX_VALUE)
                .addContainerGap())
        );

        MenuTabs2.addTab("Review Cart Items", jPanel8);
        MenuTabs2.setBackgroundAt(0, Color.RED);
        //MenuTabs2.setBackgroundAt(1, Color.GREEN);

        javax.swing.GroupLayout myContentPaneLayout = new javax.swing.GroupLayout(myContentPane);
        myContentPane.setLayout(myContentPaneLayout);
        myContentPaneLayout.setHorizontalGroup(
            myContentPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(myContentPaneLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(myContentPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Paymentmode_panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, myContentPaneLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(keyboard_panel, javax.swing.GroupLayout.PREFERRED_SIZE, 704, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Menu_select_panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(m_text, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(MenuTabs2))
                .addContainerGap())
        );
        myContentPaneLayout.setVerticalGroup(
            myContentPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, myContentPaneLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(m_text, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(MenuTabs2, javax.swing.GroupLayout.PREFERRED_SIZE, 550, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
                .addComponent(Menu_select_panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 22, Short.MAX_VALUE)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 17, Short.MAX_VALUE)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 29, Short.MAX_VALUE)
                .addComponent(keyboard_panel, javax.swing.GroupLayout.PREFERRED_SIZE, 307, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 29, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Paymentmode_panel, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40))
        );

        jScrollPane1.setViewportView(myContentPane);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cmdguestActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdguestActionPerformed

        if (cmdguest.getText().equalsIgnoreCase("Cancel")) {
            process_back_to_start();
        } else {
            txt_staff_pin.setVisible(true);
            cmd_enroll.setVisible(false);
            txtid.setVisible(false);
            cmdstart.setVisible(false);
            main_separator.setVisible(false);
            cmdback.setVisible(true);
            m_text.setText("Enter The Guest PIN And Click The Button Again");

            clickcount = clickcount + 1;
//            try {
//                Runtime.getRuntime().exec("cmd /c osk");
//                txt_staff_pin.requestFocus();
//            } catch (IOException e) {
//
//                logger.log(Level.SEVERE, "Error Opening Virtual Keyboard {0} ", e.getMessage());
//            }

 //create virtual Keyboard
 VirtualKeyboard vk = new VirtualKeyboard();
         keyboard_panel.removeAll();
        vk.show(this, keyboard_panel);
        keyboard_panel.setVisible(true);
        txt_staff_pin.requestFocus();

            if (clickcount > 1) {

                if (!txt_staff_pin.getText().isEmpty()) {

                    load_guest_menu(txt_staff_pin.getText().trim());
                } else {

                    m_text.setText("Invalid Guest PIN");
                    // m_text.setForeground(Color.red);

                }

            }

//        try {
//            Open();// TODO add your handling code here:
//        } catch (SQLException ex) {
//            System.out.println(ex);
//        }
        }
    }//GEN-LAST:event_cmdguestActionPerformed

    private void cmdverifyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdverifyActionPerformed
        boolean valid_id = false;
        boolean has_print = false;
        if (!txtid.getText().isEmpty()) {

            try {

                valid_id = db.checkuser_id(txtid.getText());
                has_print = db.checkuser_print(txtid.getText());

            } catch (SQLException e) {

            }

            if (valid_id == true) {

                System.out.println("Proceed to check for fingerprints");

                if (has_print == true) {

                    System.out.println("Proceed to verification");
                } else {

                    System.out.println("Proceed to Enrollment");
                }
            } else {

                System.out.println("Invalid ID");

            }

        } else {

            m_text.setText("Invalid ID/PIN Found");
        }

        // TODO add your handling code here:
    }//GEN-LAST:event_cmdverifyActionPerformed

    private void cmdstartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdstartActionPerformed

        if (cmdstart.getText().equalsIgnoreCase("Complete")) {
            
            if(tblcart_items.getRowCount()<=0){
            
                  m_text.setText("Your Cart is Empty. Add Menu Items.");
                  
                  
            
            }else{

            m_text.setText("Select Payment Method");

            if(NO_OF_SELECTED_MENU_ITEMS<=0){
            
                m_text.setText("Select a Menu Item and Press Complete.");
                return;
           
            }
            
                System.out.println("Amount To PAy ==>"+AMOUNT_TO_PAY);
            
//            if(AMOUNT_TO_PAY<150){
//                
//                
//            
//                  m_text.setText("Item(s) selected should equal/Over the discount Amount.");
//            
//            }
            
           // else{
            
           // Paymentmode_panel.setVisible(true);

            try {
                
                save_data("");
                
                 if (save_data) {

                    process_verification();
                } else {
                    m_text.setText("ERROR - Contact Support");

                }

               // load_payment_modes();
               
               
               
               
               
            } catch (Exception ex) {
                Logger.getLogger(App.class.getName()).log(Level.SEVERE, null, ex);
                App.logger.log(Level.WARNING, "Error Loading Payment Modes Button {0}", ex.getMessage());
            }
            cmdstart.setText("Start");
            cmdstart.setVisible(false);
            }
            
          //  }

        } else {

            boolean valid_id = false;
            boolean has_print = false;
            
            


            if (!txtid.getText().isEmpty()) {

                try {

                    valid_id = db.checkuser_id(txtid.getText().trim());
                    // has_print = db.checkuser_print(txtid.getText());

                } catch (SQLException e) {

                }

                if (valid_id == true) {

                    m_text.setText("ID Verified, Follow Instructions Below to Register");
                    txtid.setVisible(false);
                    cmdstart.setVisible(false);
//                            System.out.println("Proceed to check for fingerprints");
                    cmd_enroll.setVisible(false);

                    cmdguest.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/icons8-cancel-64.png"))); // NOI18N

                     keyboard_panel.setVisible(false);
                    cmdguest.setText("Cancel");

                    begin_enrollment();
                    // process_enrollment();
//                            if(has_print==true){
//                                
//                           
//                             System.out.println("Proceed to verification");   
//                            }else{
//                            
//                               begin_enrollment();
//                            System.out.println("Proceed to Enrollment"); 
//                            }
                } else {

                    System.out.println("Invalid ID");
                    m_text.setText("Invalid ID");

                }

            } else {

                m_text.setText("Invalid ID/PIN Found");

            }

        }
// TODO add your handling code here:
    }//GEN-LAST:event_cmdstartActionPerformed

    private void cmd_enrollActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmd_enrollActionPerformed
        cmdstart.setVisible(true);
        cmdstart.setEnabled(true);
        cmdstart.setText("Start");

        txtid.setVisible(true);
        m_text.setText("Enter your Staff ID and Click Start");
        try {
//            Runtime.getRuntime().exec("cmd /c osk");
//            txtid.grabFocus();
//            txtid.setText("Type your ID/PIN here");
//            txtid.selectAll();

VirtualKeyboard vk = new VirtualKeyboard();
keyboard_panel.removeAll();
        vk.show(this, keyboard_panel);
        keyboard_panel.setVisible(true);
txtid.requestFocus();
//txtid.setText("Type your ID/PIN here");
            txtid.selectAll();
            //setFocusableWindowState(true);
        } catch (Exception e) {

            logger.log(Level.SEVERE, "Error Opening Virtual Keyboard {0} ", e.getMessage());
        }
        txtid.requestFocus();

// close reader

    }//GEN-LAST:event_cmd_enrollActionPerformed

    private void txtidFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtidFocusGained
//        try {
//            Runtime.getRuntime().exec("cmd /c osk");
//            txtid.grabFocus();
//        } catch (IOException e) {
//
//            logger.log(Level.SEVERE, "Error Opening Virtual Keyboard {0} ", e.getMessage());
//        }
//        txtid.requestFocus();
        // TODO add your handling code here:
    }//GEN-LAST:event_txtidFocusGained

    private void cmdcancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdcancelActionPerformed
//StopCaptureThread();
//		
//		//wait for capture thread to finish
//		WaitForCaptureThread();
//		
//		//close reader
//		try{
//			m_reader.Close();
//		}
//		catch(UareUException e){ MessageBox.DpError("Reader.Close()", e); }
//	
// TODO add your handling code here:

        if (null == m_reader) {
            MessageBox.Warning("Reader is not selected");
        } else {
            Enrollment_new.Run(m_reader);
        }
    }//GEN-LAST:event_cmdcancelActionPerformed

    private void cmdbackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdbackActionPerformed
//hide_menu();
//
////load_templates_from_db();
//reload_templates_from_db();
//re_initialize_reader();
//// open reader
//		try {
//			m_reader.Open(Reader.Priority.COOPERATIVE);
//                         startVerification(m_reader);
//                        
//		} catch (UareUException e) {
//			MessageBox.DpError("Reader.Open()", e);
//                       
//		}
//       
//cmdback.setVisible(false);// TODO add your handling code here:

        process_back_to_start();
    }//GEN-LAST:event_cmdbackActionPerformed

    private void txt_staff_pinFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_staff_pinFocusGained
//        try {
//            Runtime.getRuntime().exec("cmd /c osk");
//            txt_staff_pin.grabFocus();
//        } catch (IOException e) {
//
//            logger.log(Level.SEVERE, "Error Opening Virtual Keyboard {0} ", e.getMessage());
//        }
//        txt_staff_pin.requestFocus();  

keyboard_panel.setVisible(true);

// TODO add your handling code here:
    }//GEN-LAST:event_txt_staff_pinFocusGained

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
//MenuPanel.setVisible(false);  
      //  load_menu("1018");
// TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed


    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

        int payment_method = Integer.parseInt(db.get_payment_method_ID("Float"));
 
        double discount_amt = 150;

        for (int i = 0; i < tblmenu.getRowCount(); i++) {

            if (tblmenu.getModel().getValueAt(i, 12).equals("1")) {

                String staff_id = tblmenu.getValueAt(i, 0).toString();
                int menu_id = Integer.parseInt(tblmenu.getValueAt(i, 1).toString());
                double menu_price = Double.parseDouble(tblmenu.getValueAt(i, 3).toString());
                tblmenu.setValueAt(discount_amt, i, 4);
                double total_amount = menu_price - discount_amt;//    Double.parseDouble(tblmenu.getValueAt(i, 5).toString());
                tblmenu.setValueAt(total_amount, i, 5);
                String receipt_no = tblmenu.getValueAt(i, 6).toString();
                    save_data = 
db.insertMenuTransaction(staff_id,
                            menu_id,
                            menu_price,
                            discount_amt,
                            total_amount,
                            payment_method,
                            receipt_no,
                            0);

                discount_amt = 0;

            }

            logger.log(Level.INFO, "Saved menu Transaction Data {0}", save_data);
        }
        
        System.out.println("Save Data "+save_data);

        // send_to_printer();      // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        //  load_payment_modes();        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void txt_staff_pinFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_staff_pinFocusLost
//keyboard_panel.setVisible(false);        // TODO add your handling code here:
    }//GEN-LAST:event_txt_staff_pinFocusLost

    private void cmdaddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdaddActionPerformed
        Integer current_value = Integer.parseInt(txtqty.getText());

        current_value++;
        txtqty.setText(String.valueOf(current_value));

        // TODO add your handling code here:
    }//GEN-LAST:event_cmdaddActionPerformed

    private void cmdminusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdminusActionPerformed
        Integer current_value = Integer.parseInt(txtqty.getText());

        current_value--;

        if (current_value < 1) {
            current_value++;
        }
        txtqty.setText(String.valueOf(current_value));        // TODO add your handling code here:
    }//GEN-LAST:event_cmdminusActionPerformed

    private void cmd_add_to_cartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmd_add_to_cartActionPerformed

        if (cmbitems.getModel().getSize() <= 0) {
            System.out.println("Nothing to Add");
        } else {

            String menu_item = cmbitems.getSelectedItem().toString();
            int qty = Integer.parseInt(txtqty.getText());

            db.add_menu_item_to_cart(menu_item, qty, tblcart_items);
            
            
            DiscountDistributorSequential();
           // Calculate_Amount_toPay();
            
            
            
               // update_selected_menu(menu_item,  "1",qty) ;
                
                txtqty.setText("1");


        }        // TODO add your handling code here:
    }//GEN-LAST:event_cmd_add_to_cartActionPerformed

    private void tblcart_itemsPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_tblcart_itemsPropertyChange

        //        if(tblcart_items.getSelectedRow()>0){
            //
            //        String menu_item = tblcart_items.getValueAt(tblcart_items.getSelectedRow(), 0).toString();
            //            update_selected_menu(menu_item, "0", 1);
            //        }

        // TODO add your handling code here:
        
       
    }//GEN-LAST:event_tblcart_itemsPropertyChange

    private void m_textPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_m_textPropertyChange
    App.logger.log(Level.INFO, "Staff PIN {0} : Data : {1}", new Object[]{STAFF_ID, m_text.getText()});        // TODO add your handling code here:
    }//GEN-LAST:event_m_textPropertyChange

    public PrintService findPrintService(String printerName) {
        for (PrintService service : PrinterJob.lookupPrintServices()) {
            if (service.getName().equalsIgnoreCase(printerName)) {
                return service;
            }
        }

        return null;
    }

    void send_to_printer() {

        //System.out.println(PrintServiceLookup.lookupDefaultPrintService().getName());
        logger.log(Level.INFO, "Available Printer : {0}", PrintServiceLookup.lookupDefaultPrintService().getName());
//Task<Void> delayTask = delayTask(1000);
// System.out.println("Delay started: ");
//        delayTask.setOnSucceeded(e -> {
//            printReceiptWaitProcess();
//        });
//
//        delayTask.setOnFailed(e -> {
//            App.logger.info("Delay exception: "
//                    + delayTask.getException().getMessage());
//            System.out.println("Delay exception: "
//                    + delayTask.getException().getMessage());
//            printReceiptWaitProcess();
//            
//        });
//
//        Executors.newSingleThreadExecutor().execute(delayTask);
        // TODO add your handling code here:
        int row = tblmenu.getRowCount();

        if (row > 0) {
           RECEIPT_NO = UtData.RECEIPT_NO;// tblmenu.getValueAt(0, 6).toString();
//
//            for (int i = 0; i < row; i++) {
//
//                String menu_item = tblmenu.getValueAt(i, 2).toString();
//                double item_cost = Double.parseDouble(tblmenu.getValueAt(i, 5).toString());
//                String selected = tblmenu.getValueAt(i, 12).toString();
//
//                if (selected.equalsIgnoreCase("1")) {
//
//                    SELECTED_ITEM_MENU.add(menu_item);
//                    SELECTED_ITEM_COST.add(item_cost);
//
//                    AMOUNT_TO_PAY = AMOUNT_TO_PAY + item_cost;
//
//                }
//
//                // MENU = MENU+ tblmenu.getValueAt(i, 2).toString()+" \n";
//            }

            PrintService ps = findPrintService(PrintServiceLookup.lookupDefaultPrintService().getName());
            try {
                PrinterJob pj = PrinterJob.getPrinterJob();
                pj.setPrintService(ps);
                pj.setPrintable(new BillPrintable(COMPANY_NAME, ADDRESS, TELEPHONE, RECEIPT_NO, STAFF_NAME, STAFF_ID, STAFF_DEPARTMENT, SELECTED_ITEM_MENU, SELECTED_ITEM_COST, UtData.TOTAL_AMOUNT,UtData.DISCOUNT_AMOUNT,UtData.PENDING_DISCOUNT,UtData.CASH_AMOUNT), getPageFormat(pj));

                m_text.setText("Printing");
                pj.print();
                //  hide_menu();
                //startVerification(m_reader);

            } catch (PrinterException ex) {
                System.out.println(ex);
            }
        }

    }

    public PageFormat getPageFormat(PrinterJob pj) {

        PageFormat pf = pj.defaultPage();
        Paper paper = pf.getPaper();

        double bodyHeight = 0.0;
        double headerHeight = 5.0;
        double footerHeight = 5.0;
        double width = cm_to_pp(8);
        double height = cm_to_pp(headerHeight + bodyHeight + footerHeight);
        paper.setSize(width, height);
        paper.setImageableArea(0, 10, width, height - cm_to_pp(1));

        pf.setOrientation(PageFormat.PORTRAIT);
        pf.setPaper(paper);

        return pf;
    }

    protected static double cm_to_pp(double cm) {
        return toPPI(cm * 0.393600787);
    }

    protected static double toPPI(double inch) {
        return inch * 72d;
    }

    void begin_enrollment() {

        StopCaptureThread();
//StartCaptureThread();

        re_initialize_reader();

//m_enrollment.cancel();
        if (null == m_reader) {
            MessageBox.Warning("Reader is not selected");

        } else {

            Enrollment2.Run(m_reader);
        }

    }

    
    
    void load_categories_menu(){
    
          List<categories> menu_buttons = db.getCategoryList();
          
          MenuCategories.removeAll();

        MenuCategories.updateUI();

        for (categories i : menu_buttons) {

            JButton boton = new JButton(i.getCategory_name());

            boton.setFont(new java.awt.Font("Tahoma", 1, 14));

            MenuCategories.add(boton, BorderLayout.SOUTH);

           
            MenuCategories.updateUI();
            boton.addActionListener((ActionEvent e) -> {
                System.out.println(boton.getText());

                boton.setBackground(new java.awt.Color(240, 240, 240));

                String cat_id = db.get_menu_Cat_ID(boton.getText());

                System.out.println("Cat ID " + cat_id);
                
                Menu_select_panel.setVisible(true);

                if (cmbitems.getModel().getSize() <= 0) {
                    db.getMenuList_by_category(cat_id, cmbitems);
                    
                    if(cmbitems.getModel().getSize()>0){
                    
                        m_text.setText("Select Menu Item And Add to Cart");
                    
                    }else{
                    
                         m_text.setText("No Category Menu Available ");
                    
                    
                    }
                } else {

                    cmbitems.removeAllItems();

                    db.getMenuList_by_category(cat_id, cmbitems);
                    
                    
                     if(cmbitems.getModel().getSize()>0){
                    
                        m_text.setText("Select Menu Item And Add to Cart");
                    
                    }else{
                    
                         m_text.setText("No Category Menu Available ");
                    
                    
                    }
                }
                
                                    NO_OF_SELECTED_MENU_ITEMS = NO_OF_SELECTED_MENU_ITEMS + 1;

                if (boton.isSelected()) {

                    App.logger.log(Level.INFO, "Menu Item Selected {0}", boton.getText());

                    NO_OF_SELECTED_MENU_ITEMS = NO_OF_SELECTED_MENU_ITEMS + 1;
                    // boton.setBackground(Color.GREEN);
                    boton.setBackground(new java.awt.Color(51, 153, 0));
                    //boton.setBorderPainted(false);
                } else {

                    boton.setBackground(new java.awt.Color(240, 240, 240));

                    NO_OF_SELECTED_MENU_ITEMS = NO_OF_SELECTED_MENU_ITEMS - 1;

                    App.logger.log(Level.INFO, "Menu Item DeSelected {0}", boton.getText());
                    //boton.setBorderPainted(true);
                }

            });

        }
    
    
    }
    
    
    void load_menu(String Staff_ID) {

        List<menus> list = db.getMenuList();

        List<staffDetails> staff_details_list = db.getStaffDetails(Staff_ID);

        String inv_no = db.generateReceipt();
        
        UtData.RECEIPT_NO=inv_no;
        
        

        DefaultTableModel model = (DefaultTableModel) tblmenu.getModel();

        //  menu_transactions tr = new menu_transactions();
        double total_amount;
        Object rowData[] = new Object[13];

      //  boolean save_data = false;

        for (int i = 0; i < list.size(); i++) {
            rowData[0] = Staff_ID;
            rowData[1] = list.get(i).getMenu_id();
            rowData[2] = list.get(i).getMenu_name();
            rowData[3] = list.get(i).getMenu_price();
            rowData[4] = list.get(i).getDiscount_amt();

            total_amount = list.get(i).getMenu_price()
                    - list.get(i).getDiscount_amt();
            rowData[5] = total_amount;
            rowData[6] = inv_no;

            rowData[7] = "";
            rowData[8] = "";
            rowData[9] = "";
            rowData[10] = "";
            rowData[11] = "";
            rowData[12] = "0";

//           tr.setStaff_id(Staff_ID);
//           tr.setMenu_id(list.get(i).getMenu_id());
//           tr.setMeal_cost(list.get(i).getMenu_price());
//           tr.setDiscount_amt(list.get(i).getDiscount_amt());
//           tr.setPaid_amt(total_amount);
//           tr.setPayment_method(0);
//           tr.setReceipt_no((String) rowData[6]);
//           tr.setBooking_id(0);
//                   
            // String details = rowData[2]+" @"+rowData[3];  
            String details = rowData[2].toString();

            System.out.println("Data " + rowData[2]);

            model.addRow(rowData);
           // load_menu_buttons(details);


        }
  load_categories_menu();      

        if (model.getRowCount() > 0) {
            cmdstart.setText("Complete");
            cmdstart.setVisible(true);
        }

        STAFF_NAME = staff_details_list.get(0).getStaffName();
        STAFF_DEPARTMENT = staff_details_list.get(0).getStaffDepartment();
        STAFF_ID = staff_details_list.get(0).getStaffID();
        UtData.STAFF_ID=STAFF_ID;

        UtData.UTILIZED_DISCOUNT= db.Utilized_discount_amount(today, STAFF_ID);
        
        App.elogger.debug("Utilized Discount Today ==>"+UtData.UTILIZED_DISCOUNT);
        
        App.elogger.debug("Staff ID Loaded ==>"+UtData.STAFF_ID);
        
        App.elogger.debug("Receipt No Generated ==>"+UtData.RECEIPT_NO);
         
        lbl_balance.setText("Utilized Discount Today ==>KES "+UtData.UTILIZED_DISCOUNT);
        
        
        //  logger.log(Level.INFO, "Saved menu Transaction Data {0}", save_data);
//         try {
//            db.Open();
//        } catch (SQLException ex) {
//            java.util.logging.Logger.getLogger(App.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        
//        String inv_no = db.generateReceipt();
//        tblmenu.setValueAt(inv_no, 0, 6);
//        
    }
    
    private double Calculate_Amount_toPay(){
    
        for (int i = 0; i < tblmenu.getRowCount(); i++) {

                if (tblmenu.getModel().getValueAt(i, 12).equals("1")) {
                    double menu_price = Double.parseDouble(tblmenu.getValueAt(i, 3).toString());
                    AMOUNT_TO_PAY = AMOUNT_TO_PAY + menu_price;

                }
                
                App.elogger.debug("Calculate Amount ToPAY==>"+AMOUNT_TO_PAY);
                
               
       App.elogger.debug("Table Size "+tblcart_items.getRowCount());
        App.elogger.debug("List Size "+UtData.SELECTED_MENU_ITEMS.size());
   

               // logger.log(Level.INFO, "Calculate Amount ", save_data);
            }
        
        
        return AMOUNT_TO_PAY;
    
    }
    
    
    public void DiscountDistributorSequential() {
   
       
        double totalDiscount = 150-UtData.UTILIZED_DISCOUNT;
        App.elogger.debug("Current total Discount ==>"+totalDiscount);
        double originalTotalDiscount = totalDiscount; // Store the original discount amount

        // Distribute the discount sequentially
        for (int i = 0; i < tblcart_items.getRowCount(); i++) {
//            if (totalDiscount <= 0) {
//                break; // Stop if no discount is left
//            }
            double item_price = Double.parseDouble(tblcart_items.getValueAt(i, 3).toString());
            // Calculate discount to apply to the current item
            double discountToApply = Math.min(totalDiscount, item_price);
            
            tblcart_items.setValueAt(discountToApply, i, 5);
            //item.discount = discountToApply;
            double item_cash_pay= item_price-Double.parseDouble(tblcart_items.getValueAt(i, 5).toString());
            
            tblcart_items.setValueAt(item_cash_pay, i, 7);
            // Subtract applied discount from totalDiscount
            totalDiscount -= discountToApply;
        }
        
        double  totalPrice = 0;
        double totalCashToPay = 0;
        for (int i = 0; i < tblcart_items.getRowCount(); i++) {
            double item_price = Double.parseDouble(tblcart_items.getValueAt(i, 3).toString());
            double item_discount = Double.parseDouble(tblcart_items.getValueAt(i, 5).toString());
            totalCashToPay += Math.max(0, item_price - item_discount); // Only add uncovered prices
              totalPrice += item_price;
        }
       

        // Print the items with their discounts
       // items.forEach(System.out::println);

        // Calculate total discount consumed
        double totalDiscountConsumed = originalTotalDiscount - totalDiscount;
        UtData.TOTAL_AMOUNT=totalPrice;
        UtData.DISCOUNT_AMOUNT=totalDiscountConsumed;
        UtData.PENDING_DISCOUNT=totalDiscount;
        UtData.CASH_AMOUNT=totalCashToPay;
        App.elogger.debug("Total Price Amount: " + totalPrice);
        App.elogger.debug("Total Discount Consumed: " + totalDiscountConsumed);
        App.elogger.debug("Total Pending Discount: " + totalDiscount);
        App.elogger.debug("Total Cash to Pay: " + totalCashToPay);
}
     

    void save_data(String paymode) {

        int payment_method =5;// Integer.parseInt(db.get_payment_method_ID(paymode));
        
    
      
 for (int i = 0; i < tblcart_items.getRowCount(); i++) {
     
     
     if(tblcart_items.getRowCount()>0){
            

                String staff_id =UtData.STAFF_ID;
                String menu_item=tblcart_items.getValueAt(i, 0).toString();
                int menu_id = Integer.parseInt(tblcart_items.getValueAt(i, 6).toString());
                double menu_price = Double.parseDouble(tblcart_items.getValueAt(i, 3).toString());
                double discount_amount=Double.parseDouble(tblcart_items.getValueAt(i, 5).toString());
                double paid_amount=Double.parseDouble(tblcart_items.getValueAt(i, 7).toString());
                SELECTED_ITEM_MENU.add(menu_item);
                SELECTED_ITEM_COST.add(menu_price);
                
                String receipt_no = UtData.RECEIPT_NO;
                    save_data = 
                db.insertMenuTransaction(staff_id,
                            menu_id,
                            menu_price,
                            discount_amount,
                            paid_amount,
                            payment_method,
                            receipt_no,
                            0);

     }
     else{
         
         JOptionPane.showMessageDialog(rootPane, "Your Food Cart is Empty.");
     
     }
                   

            }

            logger.log(Level.INFO, "Saved menu Transaction Data {0}", save_data);
       
           

    }

    

    
   
    
    
    void load_guest_menu(String PIN) {

        guest_info list = db.getGuestInfoFromPin(PIN);

        String inv_no = db.generateReceipt();

        DefaultTableModel model = (DefaultTableModel) tblmenu.getModel();

        if (list == null) {
            m_text.setText("Guest PIN not Found");
        } else {
            double total_amount = 0;
            Object rowData[] = new Object[12];

            try {

                rowData[0] = list.getStaff_id();
                rowData[1] = list.getMenu_id();
                rowData[2] = list.getMenu_name();
                rowData[3] = list.getMenu_price();

                rowData[4] = list.getDiscount_amt();
                total_amount = list.getMenu_price()
                        - list.getDiscount_amt();
                rowData[5] = total_amount;
                rowData[6] = inv_no;
                rowData[7] = list.getBooking_id();
                rowData[8] = list.getGuest_name();
                rowData[9] = list.getGuest_pin();
                rowData[10] = list.getStaff_name();
                rowData[11] = list.getD_name();

                model.addRow(rowData);

                STAFF_NAME = list.getStaff_name();
                STAFF_DEPARTMENT = list.getD_name();
                STAFF_ID = list.getStaff_id();

            } catch (Exception e) {

                logger.log(Level.SEVERE, "Error Loading Guest menu :{0}", e.getMessage());
                System.out.println(e.getMessage());

            }
        }

//         try {
//            db.Open();
//        } catch (SQLException ex) {
//            java.util.logging.Logger.getLogger(App.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        
//        String inv_no = db.generateReceipt();
//        tblmenu.setValueAt(inv_no, 0, 6);
//        
    }

    void load_date_time() {

        SimpleDateFormat dateFormat
                = new SimpleDateFormat("EEE, d MMM yyyy");
        SimpleDateFormat timeFormat
                = new SimpleDateFormat("h:mm:ss a");

//        Calendar currentCalendar = Calendar.getInstance();
//        Date currentTime = currentCalendar.getTime();
//        
//        lbltime_.setText(timeFormat.format(currentTime));

//         lbldate.setText(
//           DateFormat.getDateTimeInstance().format(new Date())
//         );
        Timer t = new Timer(500, (ActionEvent e) -> {
            Calendar currentCalendar1 = Calendar.getInstance();
            Date currentTime1 = currentCalendar1.getTime();
//              lbldate.setText(
//                 DateFormat.getDateTimeInstance().format(new Date())
//              );
            lbldate.setText(dateFormat.format(currentTime1));
            lbltime_.setText(timeFormat.format(currentTime1));
        });
        t.setRepeats(true);
        t.setCoalesce(true);
        t.setInitialDelay(0);
        t.start();

    }

    private void StartCaptureThread() {
        m_capture = new CaptureThread(m_reader, false,
                Fid.Format.ANSI_381_2004,
                Reader.ImageProcessing.IMG_PROC_DEFAULT);
        System.out.println("Capture Starting");
        m_capture.start(this);
        System.out.println("Capture started");
    }

    public void StopCaptureThread() {
        if (null != m_capture) {
            System.out.println("stopping the thread ...");
        }
        m_capture.cancel();
    }

    private void WaitForCaptureThread() {
        if (null != m_capture) {
            m_capture.join(1000);
        }
    }

    private boolean ProcessCaptureResult(CaptureThread.CaptureEvent evt) {
        boolean bCanceled = false;

        if (this.m_enrollmentFmd == null && this.m_listOfRecords.isEmpty()) {
//			MessageBox
//					.Warning("You cannot verify until you register or load a template.");
            // m_text.setForeground(Color.red);
            m_text.setText("Click Register");
            cmd_enroll.setVisible(true);
            main_separator.setVisible(true);
            txtid.setVisible(false);
            txtid.requestFocus();

            return !bCanceled;
        }

        if (null != evt.capture_result) {
            if (null != evt.capture_result.image
                    && Reader.CaptureQuality.GOOD == evt.capture_result.quality) {
                // extract features
                Engine engine = UareUGlobal.GetEngine();

                try {
                    //m_imagePanel.showImage(evt.capture_result.image);
                    Fmd fmd = engine.CreateFmd(evt.capture_result.image,
                            Fmd.Format.DP_VER_FEATURES);
//                                        Fmd fmd = engine.CreateFmd(evt.capture_result.image,
////							Fmd.Format.ANSI_378_2004);

                    m_fmds[0] = fmd;

                    // Lets perform 1:1 comparison
                    if (this.m_enrollmentFmd != null) {
                        m_fmds[1] = this.m_enrollmentFmd;

                        try {
                            int falsematch_rate = engine.Compare(m_fmds[0], 0,
                                    m_fmds[1], 0);

                            int target_falsematch_rate = Engine.PROBABILITY_ONE / 100000; // target
                            // rate
                            // is
                            // 0.00001
                            if (falsematch_rate < target_falsematch_rate) {
                                //m_text.setText("MATCHED !!!\n");
                                // m_text.setForeground(Color.getHSBColor(51, 153, 0));
                                m_text.setText("Verified");
//								String str = String.format(
//										"    dissimilarity score: 0x%x.\n",
//										falsematch_rate);
//								m_text.setText(str);
//								str = String
//										.format("    false match rate: %e.\n\n\n",
//												(double) (falsematch_rate / Engine.PROBABILITY_ONE));
//								m_text.setText(str);
                            } else {
                                m_text.setText("NO MATCH!!!");
                            }
                        } catch (UareUException e) {
                            //MessageBox.DpError("Engine.Compare exception()", e);
                            //m_text.setForeground(Color.RED);
                            m_text.setText("No Match Found" + e.getMessage());
                        }

                        // discard FMDs
                        m_fmds[0] = null;
                        m_fmds[1] = null;

                    } else // Perform identification
                    {
                        int target_falsematch_rate = Engine.PROBABILITY_ONE / 100000; // target
                        // rate
                        System.out.println("Forcing Array to be a label");
                        // is
//                                                      if(App.GlobalFMD!=null){
////							m_fmdArray[0]= App.GlobalFMD;
//                                                      }
                        // 0.00001
                        Engine.Candidate[] matches = engine.Identify(m_fmds[0], 0,
                                m_fmdArray, target_falsematch_rate, 1);
                        if (matches.length == 1) {
                            //							JOptionPane
                            //									.showMessageDialog(
                            //											null,
                            //											"Match found:"
                            //							
                            //                                                                                                
                            //                                                                                                
                            //                                                                                               + this.m_listOfRecords
                            //														.get(matches[0].fmd_index).userID);

                            ;
//m_text.setForeground(new java.awt.Color(51, 153, 0));

                            m_text.setText("Verified");

                            cmd_enroll.setVisible(false);

//                            if(db.Utilized_discount_amount(today, STAFF_ID)>=150){
//                           
//                                
//                                JOptionPane.showMessageDialog(null,"Transaction Not Allowed.\nYour Todays BOA Discount is depleted.");
//                               
//                            
//                            }else{
                            
                            load_menu(this.m_listOfRecords.get(matches[0].fmd_index).userID);
                          //  }
                            
                            if (tblmenu.getRowCount() > 0) {
                                MenuPanel.setVisible(true);
                                MenuTabs2.setVisible(true);
                                m_text.setText("Select Menu Category");

                                cmdguest.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/icons8-cancel-64.png"))); // NOI18N

                                cmdguest.setText("Cancel");
                                
                                
                                // process_verification();
                            } else {

                                // m_text.setForeground(Color.red);
                                m_text.setText("Menu Not Available");

                            }

                            //evt.capture_result.image=null;    
                            // 
                        } else {
//							JOptionPane.showMessageDialog(null,
//									"Not Identified!!!");

                            //evt.capture_result.image=null;
                            //  m_text.setForeground(Color.red);
                            m_text.setText("Match Not Found Click Register or Try Again");
                            cmd_enroll.setVisible(true);
                            main_separator.setVisible(true);
                            txtid.setVisible(false);
                            txtid.requestFocus();
                        }
                    }
                } catch (UareUException e) {
                    //MessageBox.DpError("Engine.CreateFmd()", e);
                    System.out.println("ERROR" + e);
                    //  m_text.setForeground(Color.red);
                    m_text.setText("ERROR" + e.getMessage());
//                                        cmd_enroll.setVisible(true);
//                                        main_separator.setVisible(true);
//                                        txtid.setVisible(false);
//                                        txtid.requestFocus();

                }
            } else {
                // the loop continues
                //m_text.append(m_strPrompt2);

                m_text.setText(m_strPrompt2);
            }
        } else if (Reader.CaptureQuality.CANCELED == evt.capture_result.quality) {
            // capture or streaming was canceled, just quit
            bCanceled = true;
        } else if (null != evt.exception) {
            // exception during capture
            MessageBox.DpError("Capture", evt.exception);
            bCanceled = true;
        } else if (null != evt.reader_status) {
            // reader failure
            MessageBox.BadStatus(evt.reader_status);
            bCanceled = true;
        } else {
            // bad quality
            MessageBox.BadQuality(evt.capture_result.quality);
        }

        return !bCanceled;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(final String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
//            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
//                if ("Nimbus".equals(info.getName())) {
//                    // UIManager.setLookAndFeel("com.jtattoo.plaf.mcwin.McWinLookAndFeel");
//                    // UIManager.setLookAndFeel("com.jtattoo.plaf.smart.SmartLookAndFeel");
//                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
//                    break;
//                }
//            }

   UIManager.setLookAndFeel( new FlatArcOrangeIJTheme() );
    UIManager.put("defaultFont", new Font(FlatRobotoFont.FAMILY, Font.PLAIN, 13));
//UIManager.setLookAndFeel("com.jtattoo.plaf.mcwin.McWinLookAndFeel");
//UIManager.setLookAndFeel("com.jtattoo.plaf.texture.TextureLookAndFeel");
            //UIManager.setLookAndFeel("com.jtattoo.plaf.smart.SmartLookAndFeel");
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(App.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
//    App frame = new App();
//       GraphicsDevice gs = GraphicsEnvironment.getLocalGraphicsEnvironment().
//  getDefaultScreenDevice();
//   //or initialize this for a specific display Frame frame = new Frame(gs.getDefaultConfiguration());
//Window win = new Window(frame);
//Canvas c = new Canvas();
////c.setBackground(Color.RED);
//
//win.add(c);
//win.setVisible(true);
////win.show();
// //or setVisible(true);
//  //Enter full-screen mode
//          gs.setFullScreenWindow(win);
////win.validate();

        //</editor-fold>
        //</editor-fold>
//    App frame = new App();   
//       GraphicsDevice gs = GraphicsEnvironment.getLocalGraphicsEnvironment().
//  getDefaultScreenDevice();
//   //or initialize this for a specific display Frame frame = new Frame(gs.getDefaultConfiguration());
//Window win = new Window(frame);
//Canvas c = new Canvas();
////c.setBackground(Color.RED);
//
//win.add(c);
//win.setVisible(true);
////win.show();
// //or setVisible(true);
//  //Enter full-screen mode
//          gs.setFullScreenWindow(win);
////win.validate();
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new App().setVisible(true);

//            Rectangle r = GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds();
//    App frame = new App();
//    frame.setDefaultCloseOperation(App.EXIT_ON_CLOSE); 
//    frame.setUndecorated(true);
//    frame.setSize(r.width, r.height);
//    frame.setVisible(true);
//            
        });

    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel MainPanel;
    private javax.swing.JPanel MenuCategories;
    private javax.swing.JPanel MenuPanel;
    private javax.swing.JTabbedPane MenuTabs2;
    private javax.swing.JPanel Menu_select_panel;
    private javax.swing.JPanel Paymentmode_panel;
    private javax.swing.JComboBox<String> cmbitems;
    private javax.swing.JButton cmd_add_to_cart;
    private static javax.swing.JButton cmd_enroll;
    private javax.swing.JButton cmdadd;
    public static javax.swing.JButton cmdback;
    private javax.swing.JButton cmdcancel;
    private javax.swing.JButton cmdguest;
    private javax.swing.JButton cmdminus;
    private static javax.swing.JButton cmdstart;
    private javax.swing.JButton cmdverify;
    public static javax.swing.JLabel fmd_output;
    public static javax.swing.JScrollPane fprint_scrollpane;
    public static javax.swing.JTextArea fprint_text;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel keyboard_panel;
    private javax.swing.JLabel lbl_balance;
    private javax.swing.JLabel lbldate;
    private static javax.swing.JLabel lblmenu;
    public static javax.swing.JLabel lblprogress;
    private javax.swing.JLabel lblststatus1;
    private javax.swing.JLabel lbltime_;
    public static javax.swing.JLabel m_text;
    private static javax.swing.JSeparator main_separator;
    public javax.swing.JPanel myContentPane;
    private javax.swing.JTable tblcart_items;
    private static javax.swing.JTable tblmenu;
    private static javax.swing.JScrollPane tblmenu_scrollPane;
    private javax.swing.JScrollPane tbltablescroll2;
    public static javax.swing.JTextField txt_staff_pin;
    public static javax.swing.JTextField txtid;
    private javax.swing.JLabel txtqty;
    // End of variables declaration//GEN-END:variables

//    void begin_verification(){
//    
//        try {
//				this.m_collection = UareUGlobal.GetReaderCollection();
//				m_collection.GetReaders();
//			} catch (UareUException e1) {
//				// TODO Auto-generated catch block
//				JOptionPane.showMessageDialog(null, "Error getting collection");
//				return;
//			}
//
//			if (m_collection.size() == 0) {
//				MessageBox.Warning("Reader is not selected");
//				return;
//			}
//
//			m_reader = m_collection.get(0);
//
//			if (null == m_reader) {
//				MessageBox.Warning("Reader is not selected");
//			} else {
//				Verification.Run(m_reader, this.enrollmentFMD);
//			}
//    
//    }
    public void startVerification(Reader reader) {
        // open reader

//              if(!hardware_initialized){
//           
//              
//              
//              try{
//			reader.Open(Reader.Priority.COOPERATIVE);
//              
//		} catch (UareUException e) {
//			MessageBox.DpError("Reader.Open()", e);
//		}
//                
//              }  
        // start capture thread
        StartCaptureThread();

        // put initial prompt on the screen
        //m_text.append(m_strPrompt1);
        m_text.setText(m_strPrompt1);

//            m_enrollment.start();
        //m_enrollmentFmd.start
        // bring up modal dialog
//		m_dlgParent = dlgParent;
//		m_dlgParent.setContentPane(this);
//		m_dlgParent.pack();
//		m_dlgParent.setLocationRelativeTo(null);
//		m_dlgParent.toFront();
//		m_dlgParent.setVisible(false);
//		m_dlgParent.dispose();
        // cancel capture
        //StopCaptureThread();
        // wait for capture thread to finish
        //WaitForCaptureThread();
        // close reader
//		try {
//			m_reader.Close();
//		} catch (UareUException e) {
//			MessageBox.DpError("Reader.Close()", e);
//		}
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getActionCommand().equals(ACT_BACK)) {
            // cancel capture
            StopCaptureThread();

        }

        if (e.getActionCommand().equals(CaptureThread.ACT_CAPTURE)) {
            // process result
            CaptureThread.CaptureEvent evt = (CaptureThread.CaptureEvent) e;
            if (evt.capture_result.image != null) {
                if (ProcessCaptureResult(evt)) {
                    // restart capture thread
                    WaitForCaptureThread();
                    StartCaptureThread();
                } else {
                    // destroy dialog
                    //m_dlgParent.setVisible(false);
                    // StopCaptureThread();
                    System.out.println("Stopped ");
                }
            }
        }

        //Enrollment
    }

//      SwingWorker<String, String> x12 ;
//              
//            x12=  new SwingWorker<String, String>() {
//        @Override
//        protected String doInBackground() throws Exception {
//            final long tid = Thread.currentThread().getId();
//            System.out.println("");
//            System.out.println("TID=" + tid + " doInBackground() isEventDispatchThread=" + SwingUtilities.isEventDispatchThread());
//            System.out.println("Long running code goes here.");
//            return "";
//        }
//
//        @Override
//        protected void done() {
//            final long tid = Thread.currentThread().getId();
//            System.out.println("");
//            System.out.println("TID=" + tid + "          done() isEventDispatchThread=" + SwingUtilities.isEventDispatchThread());
//            System.out.println("GUI updates/changes go here.");
//        }
//        
//      
//     
//    };
//    x.execute();
//    x.get();
    public void process_verification() {
        SwingWorker<Void, Void> worker;
        worker = new SwingWorker<Void, Void>() {

            @Override
            protected Void doInBackground() {

                //   form.setVisible(true);
                //Create blank workbook
                //This data needs to be written (Object[])
//       if (null != m_reader) {
//				       begin_verification();
//			}
//       
                if (tblcart_items.getRowCount() > 0) {

                    send_to_printer();                           // show_menu();   
                }

                return null;
            }

            @Override
            protected void done() {
                lblprogress.setVisible(false);
                m_text.setText(m_strPrompt1);
                hide_menu();
                reset();

            }

            @Override
            protected void process(List chunks) {

                super.process(chunks);

            }

        };

        worker.execute();

        lblprogress.setVisible(true);
    }

    public void process_enrollment() {
        SwingWorker<Void, Void> worker;
        worker = new SwingWorker<Void, Void>() {

            @Override
            protected Void doInBackground() {

//       
                begin_enrollment();

                return null;
            }

            @Override
            protected void done() {

//                m_text.setText(m_strPrompt1);
//                hide_menu();
//                reset();
//
//                Initialize_Reader();
                process_back_to_start();

            }

            @Override
            protected void process(List chunks) {

                super.process(chunks);

            }

        };

        worker.execute();

    }

    public void process_back_to_start() {
        SwingWorker<Void, Void> worker;
        worker = new SwingWorker<Void, Void>() {

            @Override
            protected Void doInBackground() {

//       
//hide_menu();
//load_templates_from_db();
                reload_templates_from_db();
                re_initialize_reader();
// open reader
                try {
                    m_reader.Open(Reader.Priority.COOPERATIVE);
                    startVerification(m_reader);

                } catch (UareUException e) {
                    MessageBox.DpError("Reader.Open()", e);

                }

// TODO add your handling code here:
                return null;
            }

            @Override
            protected void done() {
                lblprogress.setVisible(false);
                
                keyboard_panel.setVisible(false);

                cmdback.setVisible(false);

                hide_menu();

                cmdguest.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/icons8-reception-64.png"))); // NOI18N

                cmdguest.setText("Non Staff");

                reset();

            }

            @Override
            protected void process(List chunks) {

                super.process(chunks);

            }

        };

        worker.execute();

        lblprogress.setVisible(true);
    }

}
