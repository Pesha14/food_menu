/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MenuApp;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author USER
 */
public class Test {
    
 private class Item {
    String name;
    int price;
    int discount;

    public Item(String name, int price) {
        this.name = name;
        this.price = price;
        this.discount = 0;
    }

    @Override
    public String toString() {
        return "Item{" +
                "name='" + name + '\'' +
                ", price=" + price +
                ", discount=" + discount +
                '}';
    }
}

 
 
 void output_data(){
 
  List<Item> items = new ArrayList<>();
        items.add(new Item("pencil", 20));
        items.add(new Item("book", 70));
        items.add(new Item("rubber", 30));
        items.add(new Item("sharpener", 30));

        int totalDiscount = 100;
        int originalTotalDiscount = totalDiscount;

        // Distribute the discount sequentially
        for (Item item : items) {
            if (totalDiscount <= 0) {
                break; // Stop if no discount is left
            }

            // Calculate discount to apply to the current item
            int discountToApply = Math.min(totalDiscount, item.price);
            item.discount = discountToApply;

            // Subtract applied discount from totalDiscount
            totalDiscount -= discountToApply;
        }

        // Print the items with their discounts
        items.forEach(System.out::println);
        
        int totalDiscountConsumed = originalTotalDiscount - totalDiscount;
        System.out.println("Total Discount Consumed: " + totalDiscountConsumed);
        System.out.println("Total Pending Discount: " + totalDiscount);
    
 }

    public static void main(String[] args) {
        
        new Test().output_data();
        
       }   
    
    
}
