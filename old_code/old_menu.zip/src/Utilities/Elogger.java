/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Utilities;

import MenuApp.App;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import static org.apache.log4j.LogManager.getLogger;
import org.apache.log4j.Logger;



/**
 *
 * @author USER
 */
public class Elogger {
 
    

    private final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss:SSS");
    private final String requestLogString = "%s LEVEL: %s => %s";
    private final Logger logger = getLogger(App.class);
    private final ExecutorService logService = Executors. newFixedThreadPool(10);

    public void info(String logMsg){


        logService.execute(()->{
            String logLevel = "INFO";
            String msg = String.format(requestLogString,getLogTimeString(),logLevel,logMsg);
           
        });
        logger.info(logMsg);




    }

    public void debug(String logMsg){
        logService.execute(()->{
            String logLevel = "DEBUG";
            String msg = String.format(requestLogString,getLogTimeString(),logLevel,logMsg);
                     // RAccess.post_Log(msg);
        });
        logger.debug(logMsg);
    }

    public void error(String errorKey, Exception errorException){
        logService.execute(()->{
            String logLevel = "ERROR";
            String msg = String.format(requestLogString,getLogTimeString(),logLevel,
                    errorKey + errorException.getMessage());
           // RAccess.post_Log(msg);
        });
        logger.error(errorKey + errorException.getMessage());
    }

    private String getLogTimeString() {
        return LocalDateTime.now().format(DATE_TIME_FORMATTER);
    }

    public void trace(String this_is_a_Trace) {
       //logger.t(this_is_a_Trace); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void warn(String this_is_a_Warn) {
        logger.warn(this_is_a_Warn); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }


    
    
}
