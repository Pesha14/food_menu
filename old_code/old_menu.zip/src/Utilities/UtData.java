/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Utilities;

import Models.Items;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author USER
 */
public class UtData {
    
    public static double UTILIZED_DISCOUNT=0;
    public static double DISCOUNT_AMOUNT_PAID;
    public static double PENDING_DISCOUNT=0;
    public static double TOTAL_AMOUNT=0;
    
    public static String COMPANY_NAME = "";
    public static String ADDRESS = "";
    public static String TELEPHONE = "";
    public static String RECEIPT_NO = "";
    public static String STAFF_ID = "";
    public static String STAFF_NAME = "";
    public static String STAFF_DEPARTMENT = "";
    public static String MENU = "";
    public static double AMOUNT_TO_PAY;
    public static double DISCOUNT_AMOUNT;
    
    public static double CASH_AMOUNT;
    
    
    public static List<Items>SELECTED_MENU_ITEMS= new ArrayList<>();
            
            
    
    
}
